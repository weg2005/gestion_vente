from kivy.uix.screenmanager import Screen
from kivy.graphics import Rectangle, RoundedRectangle,Color
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
import os
class ScreenVersement(Screen):
    def __init__(self,**kwargs):
        super(ScreenVersement,self).__init__(**kwargs)
        
        #boxlayout 4 title 
        box_title = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.75},
        size_hint = (1,0.2))
        
        self.title = Label (text = "NOUVEAU VERSEMENT\nEnregistrer un nouveau versement",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
        box_title.add_widget (self.title)
        self.add_widget(box_title)
        # boxlayout 4 label
        
        box_label = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.48},
        size_hint = (0.5,0.3))
    
        self.label_nom = Label(text = '\nNom de la caissière/Client',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_nom)
        
        self.label_montant = Label(text = '\nMontant',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_montant)
        
        self.label_motif = Label(
        text = '\nMotif',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_motif)
        
        self.label_du = Label(
        text = '\nMontant dû',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_du)
        
        self.label_date = Label(
        text = '\nDate',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_date)
        
        self.add_widget(box_label)
        #=====================
        #  boxlayout 4 textinput
        box_textinput = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.5,'y':0.45},
        size_hint = (0.5,0.3))
        
        self.text_nom = TextInput(hint_text = 'Entrez un nom',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
       
        box_textinput.add_widget(self.text_nom)
        
        self.text_montant = TextInput(hint_text = 'Entrez un montant',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
       
        box_textinput.add_widget(self.text_montant)
        
        self.text_motif = TextInput(hint_text = 'Entrez un motif',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
       
        box_textinput.add_widget(self.text_motif)
        
        self.text_du = TextInput(hint_text = 'Montant dû',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
       
        box_textinput.add_widget(self.text_du)
        
        self.text_date = TextInput(hint_text = 'Date',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
       
        box_textinput.add_widget(self.text_date)
        
        self.add_widget(box_textinput)
        
        #=====================
        # UNE NOTE
        box_note = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.25},
        size_hint = (0.9,0.15))
        
        self.note = TextInput(
        hint_text = "NOTE (optionnelle)\nAjoutez une note...",
        background_active = '',
        background_normal = "",
        background_color = (0,0,0,0),
        foreground_color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf" )
        box_note.add_widget(self.note)
        
        self.add_widget(box_note)
        #= =======================
        # Erreur client insistant
        box_alerte = BoxLayout (
        orientation = "vertical",
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.1},
        size_hint = (0.9,0.14))
        
        self.errer_sql = Label (
        text = "CLIENT NON RECONNU\nCliquez sur 'ajouter un compte' pour l'enregistrer",
        color = (1,1,1,1),
        font_name= "Roboto-Bold.ttf")
        box_alerte.add_widget (self.errer_sql)
        # -----------------------------
        # action ajouter
        
        self.button_action = Button(
        text = "Ajoutez un compte >",
        font_name= "Roboto-Bold.ttf",
        color = (1,1,1,1),
        background_normal = "",
        background_down = "",
        background_color = (0,0,0,0)
        )
        box_alerte.add_widget (self.button_action)
        self.button_action.bind (on_press = self.vers_creation_compte)
        self
        self.add_widget (box_alerte)
        #========================
        # boxlayouts 4 actions
        # box 4 left
        
        box_left = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.02},
        size_hint = (0.4,0.07))
        
        self.anuler = Button(
        text = 'Annuler',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 40)
        self.anuler.bind (on_press = self.retoure_bord)
        box_left.add_widget (self.anuler)
        self.add_widget(box_left)
        #======================
        # box 4 right
        box_right = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.55,'y':0.02},
        size_hint = (0.4,0.07))
        
        self.valider = Button(
        text = 'Valider',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 40)
        
        box_right.add_widget (self.valider)
        self.add_widget(box_right)
        
        with self.canvas.before:
            self.rect_vers =Rectangle (source = f"{os.path.abspath('assets/images/img_font_arriere.png')}",
            )
        def resize_function (*args):
            self.rect_vers.pos = self.pos
            self.rect_vers.size = self.size
         
        self.bind(
        pos= resize_function,
        size = resize_function)
        
        with box_textinput.canvas.before:
            Color (0.5,0,0.5,0.4)
            self.roun_nom =RoundedRectangle( )
        def resize_function_nom (*args):
            self.roun_nom.pos = box_textinput.pos
            self.roun_nom.size = box_textinput.size
         
        box_textinput.bind(
        pos= resize_function_nom,
        size = resize_function_nom)
        
        with box_note.canvas.before:
            Color (0.2,0,0.6,0.4)
            self.roun_note =RoundedRectangle( )
        def resize_function_note (*args):
            self.roun_note.pos = box_note.pos
            self.roun_note.size = box_note.size
         
        box_note.bind(
        pos= resize_function_note,
        size = resize_function_note)
        
        with box_title.canvas.before:
            Color (0.2,0,0.6,0.4)
            self.roun_title =RoundedRectangle( )
        def resize_function_title (*args):
            self.roun_title.pos = box_title.pos
            self.roun_title.size = box_title.size
         
        box_title.bind(
        pos= resize_function_title,
        size = resize_function_title)
        
        with box_left.canvas.before:
            Color (0.8,0,0.,0.60)
            self.roun_left =RoundedRectangle( )
        def resize_function_left (*args):
            self.roun_left.pos = box_left.pos
            self.roun_left.size = box_left.size
         
        box_left.bind(
        pos= resize_function_left,
        size = resize_function_left)
        
        with box_right.canvas.before:
            Color (0.,0.8,0.,0.60)
            self.roun_right =RoundedRectangle( )
        def resize_function_right (*args):
            self.roun_right.pos = box_right.pos
            self.roun_right.size = box_right.size
         
        box_right.bind(
        pos= resize_function_right,
        size = resize_function_right)
        
        with box_alerte.canvas.before:
            Color (0.8,0.,0.,0.3)
            self.roun_alerte =RoundedRectangle( )
        def resize_function_alerte (*args):
            self.roun_alerte.pos = box_alerte.pos
            self.roun_alerte.size = box_alerte.size
         
        box_alerte.bind(
        pos= resize_function_alerte,
        size = resize_function_alerte)
        
    def retoure_bord (self,instance):     
        self.manager.current= "TableauBord"
        
    def vers_creation_compte(self,instance):
        self.manager.current = "CreationCompteVers"