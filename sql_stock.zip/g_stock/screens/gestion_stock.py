from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Rectangle,Color,RoundedRectangle
from kivy.uix.scrollview import ScrollView
from datetime import datetime
from kivy.uix.popup import Popup
from fpdf import FPDF
import os
class GestionStock(Screen):
  def __init__(self,**kwargs):
      super(GestionStock,self).__init__(**kwargs)
      
      # Boxlayout title
      
      box_title = BoxLayout(
      orientation = 'vertical',
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.8},
      size_hint = (1,0.2))
        
      self.title = Label (text = "Gestion de stock\nGerer les articles du stock",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
      box_title.add_widget (self.title)
        
      self.boutonretour= Button (
      text = 'Sortir >',
      font_name = 'Roboto-Bold.ttf',
      background_color = (0,0,0,0.15),
      background_normal ='')
      
      box_title.add_widget (self.boutonretour) 
      self.boutonretour.bind (on_press = self.manageretour)
      self.add_widget(box_title)
      
      # boxlayout liste
      box_action = BoxLayout (
      orientation = "vertical",
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.},
      size_hint = (1,0.75))
        
      self.button_commande = Button(
      text = "Commande d'article",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      self.button_commande.bind(on_press= self.page_commande)
      box_action.add_widget(self.button_commande)

        # bouton pour facture
      self.button_inventaire = Button(
      text = "Inventaire annuel",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      self.button_inventaire.bind(on_press = self.invanuel)
      box_action.add_widget(self.button_inventaire)
      
        # bouton de commande
      self.buttoninv_tournant = Button(
      text = "Inventaire tournant",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )

      self.buttoninv_tournant.bind(on_press = self.screeninvtournant)
      box_action.add_widget(self.buttoninv_tournant)
      
      self.button_correction = Button(
      text = "Correction de stock",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      
      box_action.add_widget(self.button_correction)
      
      self.button_transfert = Button(
      text = "Transfert d'article",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      
      box_action.add_widget(self.button_transfert)
      
      self.button_etiquette = Button(
      text = "Etiquette d'article",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      
      box_action.add_widget(self.button_etiquette)
      
      self.button_bienetre = Button(
      text = "Bien être du stock",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      
      box_action.add_widget(self.button_bienetre)
      
      self.add_widget (box_action)
     
        
      with self.canvas.before:
          self.rect = Rectangle(
          source = f"{os.path.abspath('assets/images/file_0000000074f07246a51a0f9ce144e4e3.png')}")

          
      def autoresizing(*args):
          self.rect.pos = self.pos
          self.rect.size = self.size
          
      self.bind(
      pos = autoresizing,
      size = autoresizing)
      
  def manageretour (self,instance):
       self.manager.current = 'acceil'
       
  def page_commande(self,instance):
      self.manager.current  = 'Commande'  

  def screeninvtournant(self,instance):
      self.manager.current = 'inventairetournant'

  def invanuel(self,instance):
      self.manager.current = 'inventaireanuel'