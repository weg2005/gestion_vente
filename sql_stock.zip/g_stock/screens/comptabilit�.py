from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button

class Caisse(Screen):
    def __init__(self,**skwargs):
        super(Caisse,self).__init__(**skwargs)
        pass

