from kivy.uix.screenmanager import Screen
from kivy.utils import platform
from jnius import autoclass,cast
from kivy.graphics import Rectangle,Color,Rectangle
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.boxlayout import BoxLayout
from database.connexion import print_name
from escpos.printer import Win32Raw
from database.products import(print_by_code,shearchby_code_design,get_id_depot,shearching_depot,reduct_stock)
from database.datacaisse import savecaisse_data,compteur_caisse
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from datetime import datetime
import os                
def get_times ():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

stocktemporaire = []

def add_in_basket(code,nom,quantite,prix,type_depot,id_depot,id_article,recette):
    try :
        quantite = int (quantite)
        prix = int (prix)
        stock = {"code": code,
                 "id_depot": id_depot,
                 "id_article": id_article,
                 "designation": nom,
                 "quantite" : quantite,
                 "prix": prix,
                 "recette":recette,
                 "type_depot":type_depot}
        stock['total'] = stock['quantite'] * stock['prix']
        
        stocktemporaire.append(stock)
    except ValueError :
        print ('erreur')
        
def supression_prdt():
      stocktemporaire.clear()     
            
class PageCaisse(Screen):
    def __init__(self,**kwargs):
        super(PageCaisse,self).__init__(**kwargs)
        
        self.produit_selectionne = None
    
        box_rech = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.88},
        size_hint = (1,0.07))
        
        self.shearch_name = TextInput(
        hint_text = 'Recherche designation/code/ean',
        multiline = 0,
        font_name = "Roboto-Bold.ttf",
        background_active = "",
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        
        box_rech.add_widget(self.shearch_name)
        
        self.shearch_name.bind(text = self.shearchby_name)
        
        self.shearch_name.bind(on_text_validate = self.sendinfo_name)     
        # bouton de recherche
        
        self.inputqte= TextInput(
        hint_text = 'QTE',
        text = '1',
        multiline = 0,
        font_name = "Roboto-Bold.ttf",
        background_active = "",
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1),
        font_size = 20,
        size_hint = (0.2,1))
        self.inputqte.bind (on_text_validate = self.ajouter_stockt)
        box_rech.add_widget(self.inputqte)
        
        self.add_widget(box_rech)
        
        # boxlayout label
        box_label = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.2},
        size_hint = (0.3,0.4))
        
        self.labelttc = Label (
        text = 'TTC',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        color = (1,1,1,1))
        box_label.add_widget(self.labelttc)
        
        self.labelremise = Label (
        text = 'REMISE',
        color = (1,1,1,1),
        font_name="Roboto-Bold.ttf",
        font_size = 20,
       )
        box_label.add_widget(self.labelremise)
        
        self.labelpayer = Label (
        text = 'A PAYER',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        color = (1,1,1,1))
        box_label.add_widget(self.labelpayer)
        
        self.labelrecu = Label(
        text = 'REÇU',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        color = (1,1,1,1))
        box_label.add_widget(self.labelrecu)
        
        self.labeltype = Label(
        text = 'PAIEMENT',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        color = (1,1,1,1))
        box_label.add_widget(self.labeltype)
        
        self.labeldevoir = Label(
        text = 'DEVOIR',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        color = (1,1,1,1))
        box_label.add_widget(self.labeldevoir)
        
        self.add_widget (box_label)
        
        # boxlayout input
        box_input = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.45,'y':0.2},
        size_hint = (0.55,0.4))
        
        self.textinput_ttc = TextInput(
        text = '0',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1),
        multiline = False,
        background_active = '',
        background_color = (0,0,0,0.15))
        box_input.add_widget(self.textinput_ttc)
        
        # afficheur du numero du fournisseur
        self.textinputremis = TextInput(
        text = '0',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1),
        multiline = 0,
        background_active = '',
        background_color = (0,0,0,0.15))
        
        self.textinputremis.bind(on_text_validate = self.calcule_remis)
        
        self.textinputremis.bind(on_text_validate = lambda instance: self.next_focus(self.inputrecu))
        
        box_input.add_widget(self.textinputremis)
        
        self.textinput_payer = TextInput(
        text = '0',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1),
        multiline = 0,
        background_active = '',
        background_color = (0,0,0,0.15))
        
        box_input.add_widget(self.textinput_payer)
        
        self.inputrecu = TextInput(
        hint_text = 'Entrez ici la somme',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1),
        multiline = 0,
        background_active = '',
        background_color = (0,0,0,0.15))
        
        self.inputrecu.bind(on_text_validate= self.calcule_devoir)
        
        box_input.add_widget(self.inputrecu)
        
        self.inputtype = Spinner(
        text = 'Espèce',
        values = ['Espèce','Wave','MTN','Orange','Moov'],
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        background_normal = '',
        background_color = (0,0,0,0.15))
        
        box_input.add_widget (self.inputtype)
        
        self.inputdevoir = TextInput(
        text = '0',
        font_name="Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1),
        multiline = 0,
        background_active = '',
        background_color = (0,0,0,0.15))
        
        box_input.add_widget (self.inputdevoir)
        
        self.add_widget (box_input)
       
        # boxlayout validation
        
        box_val = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.069},
        size_hint = (1,0.07))
        
        self.button_ajouter = Button(
        text= 'Ajouter',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,1,0,0.4),
        background_normal = '')
        self.button_ajouter.bind(on_press = self.ajouter_stockt)
        box_val.add_widget(self.button_ajouter)
       
        self.button_valider = Button(
        text= 'Valider',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,1,0.4),
        background_normal = '')
        box_val.add_widget(self.button_valider)
        self.button_valider.bind(on_press = self.validation_caisier)
        self.add_widget (box_val)
        
        # boxlayout anulation
        box_anul = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.},
        size_hint = (1,0.07))
        
        self.button_annule = Button(
        text= 'Suprimer',
        font_name = 'Roboto-Bold.ttf',
        background_color = (1,0.,0,0.4),
        background_normal = '')
        
        self.button_annule.bind(on_press = self.tout_suprimer)
        
        box_anul.add_widget(self.button_annule)
        
        self.boutonretour= Button (
        text = 'Sortir >',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,0,0.15),
        background_normal ='')
        
        self.boutonretour.bind (on_press = self.manageretour)
        
        box_anul.add_widget(self.boutonretour)

        self.add_widget (box_anul)
        
        # boxlayout info
        box_nom = BoxLayout(
        padding = 10,
        spacing = 10,
        size_hint = (1,0.06),
        pos_hint = {'x':0,'y':0.8})    
      
        self.labeldesignation = TextInput(
        hint_text = 'Designation',
        foreground_color = (1,1,1,1),
        font_size = 20,
        font_name="Roboto-Bold.ttf",
        background_color = (0,0,0,0.15),
        readonly= True,
        allow_copy = False,
)
        box_nom.add_widget(self.labeldesignation)

        self.labeldepot = Spinner(
        text = "type depot",
        background_color = (0,0,0,0.15),
        font_size = 20,
        font_name="Roboto-Bold.ttf",
        size_hint = (0.20,1))
        box_nom.add_widget(self.labeldepot)
        self.labeldepot.values = shearching_depot()
        self.add_widget (box_nom)
        
        #box_info
        
        box_info = BoxLayout(
        padding = 10,
        spacing = 10,
        size_hint = (1,0.08),
        pos_hint = {'x':0,'y':0.70})
        
        self.labelcode = TextInput(
        hint_text = 'Code',
        foreground_color = (1,1,1,1),
        font_size = 20,
        font_name="Roboto-Bold.ttf",
        readonly= True,
        allow_copy = False,
        background_color = (0,0,0,0.15))
        box_info.add_widget(self.labelcode)
        
        self.label_quantite = TextInput(
        hint_text = 'D_',
        foreground_color = (1,1,1,1),
        font_size = 20,
        font_name="Roboto-Bold.ttf",
        readonly= True,
        allow_copy = False,
        background_color = (0,0,0,0.15))
        box_info.add_widget(self.label_quantite)

        self.depot_2 = TextInput(
                hint_text = 'D_',
                foreground_color = (0.8,1,1,1),
                font_size = 20,
                font_name="Roboto-Bold.ttf",
                readonly= True,
                allow_copy = False,
                background_color = (0,0,0,0.15))
        box_info.add_widget(self.depot_2)
        
        self.labelticket = TextInput(
        hint_text = 'Ticket',
        foreground_color = (1,1,1,1),
        font_size = 20,
        font_name="Roboto-Bold.ttf",
        readonly= True,
        allow_copy = False,
        background_color = (0,0,0,0.15))
        
        box_info.add_widget(self.labelticket)
        self.add_widget (box_info)
        
        self.liste_article = Button (
        text = "Afficher le panier",
        font_name = 'Roboto-Bold.ttf',
        pos_hint = {'x':0,'y':0.137},
        size_hint = (1,0.06),
        background_color = (0,0,0,0.3),
        background_normal = '')
        self.add_widget (self.liste_article)
        self.liste_article.bind(on_press = self.affiche_panier)
        
        
        self.spinnernom = Spinner(
            size_hint = (1,0.02),
            pos_hint = {'x':0.,'y':0.86},
        background_color = (0,0,0,0.15),
        text = 'v')
        self.spinnernom.bind(text = self.getting_name)
        self.add_widget(self.spinnernom)
  
      # adapter la taille des image en fonction de l'ecran
        self.bind(
        size =self.get_dimention,
        pos = self.get_dimention )
        
        with self.canvas.before:
           
            self.font_arriere = Rectangle(
            source =  os.path.abspath("assets/images/img_caisse.png"),
            size = self.size,
            pos = self.pos)
            
    def  getting_name(self,instance,text):
        self.shearch_name.text = text
        
    
    def get_dimention(self,*args):
            self.font_arriere.size = self.size
            self.font_arriere.pos = self.pos
            
    def  manageretour (self,instance):
        self.manager.current = 'acceil'
             
    def shearchby_name(self,instance,text):
            result = shearchby_code_design(text) 
            self.spinnernom.values = list(result) 
        
    def sendinfo_name(self,instance):

            results = print_by_code(self.shearch_name.text)  
            if results:
              products = results [0]
              self.labeldepot.text = products[13]    
              self.resultat_design = products[2]
              self.code = products[1]
              self.type_depot = products[12]
              self.labeldesignation.text = f'{products[2]}'
              self.labelcode.text =  f'{products[1]}'
            try:  
                   depots = [] 
                   quantites = []
                   for r_depots in results:
                      quantites.append(r_depots[14])
                      depots.append(r_depots[12])

                   self.label_quantite.text = f"D{depots[0]}: {quantites[0]}"
                   self.depot_2.text = f"D{depots[1]}: {quantites[1]}"
                 
            except IndexError:
                   pass 
             
    def ajouter_stockt(self,instance) :
            try:
                results = print_by_code(self.shearch_name.text)   
                results = results [0]
                self.type_depot = get_id_depot(self.labeldepot.text)
                id_article = results [0]
                
                if self.type_depot == 1:
                 self.resultat_prix = results[11]
                 recette = int(results[11]) - int(results[9])
                else:
                 self.resultat_prix = results[10]
                 recette = int(results[10]) - int(results[8])
                 
                add_in_basket(str(self.code),str(self.resultat_design),float(self.inputqte.text),float(self.resultat_prix),self.labeldepot.text,self.type_depot,id_article,recette)   
                  
                ttc = 0
                for stockt in stocktemporaire:
                    total =stockt['total']
                    ttc += total
                    self.textinput_ttc.text = f"{ttc}"
                    remis = int(self.textinputremis.text)
                    result_remis = ttc - remis
                    self.textinput_payer.text = f"{ttc}"
                    self.inputqte.text = '1'
                    self.shearch_name.text = ''
                    
                    
            except AttributeError:
                self.erreur_v= Popup(
                title = 'ERREUR',
                content = Label(text = "S'IL VOUS PLAIT, ENTRE UNE QUANTITE"),
                size_hint= (0.8,0.2),
                pos_hint = {'x':0.1,'y':0.4})  
                self.erreur_v.open()  
            except ValueError:
                self.erreur_in= Popup(
                title = 'ERREUR',
                content = Label(text = "S'IL VOUS PLAIT VERIFIEZ LE TYPE ENTRE"),
                size_hint= (0.8,0.2),
                pos_hint = {'x':0.1,'y':0.4})  
                self.erreur_in.open()  
                
    def affiche_panier(self, instance):
        from functools import partial
        self.scroll = ScrollView()
        box = BoxLayout (
        padding = 10,
        spacing = 10,
        orientation = 'vertical',
        size_hint_y = None)
        box.bind(minimum_height = box.setter('height'))
        for i,stockt in enumerate(stocktemporaire):
            code = stockt['code']
            design =stockt['designation']
            quantite =stockt['quantite']
            prix = stockt['prix']
            total =stockt['total']       
            
            button = Button (text = f"{i} - {design} | {quantite} | {prix} | {total} ",
            font_size = 25,
            size_hint_y = None,
            font_name="Roboto-Bold.ttf",
            background_color = (0,0,0,0.55))
            
            box.add_widget(button)
            button.bind(on_press = partial(self.suprimer_prdt, i))
        self.scroll.add_widget(box)    
        self.popup = Popup(
        title="LISTE DU PANIER",
        size_hint=(0.8, 0.7),
        content=self.scroll,
        background_color = (0,0,0,0.4),
        background = ''
    )
        self.popup.open()
        
    def suprimer_prdt(self,index,*args) :
            stocktemporaire.pop(index)
            self.popup.dismiss()
            self.affiche_panier(None)
            ttc = 0
            for stockt in stocktemporaire:
                total =stockt['total']
                ttc += total
            self.textinput_ttc.text = f"{ttc}"
            self.textinput_payer.text = f"{ttc}"
            
              
    def  calcule_remis (self,instance):
                try:
                    ttc = int (self.textinput_ttc.text)
                    remis = int(self.textinputremis.text)
                    result_remis = ttc - remis
                    self.textinput_payer.text = f'{result_remis}'
                except ValueError:
                    pass
                    
    def next_focus (self,next_input):
           next_input.focus = True
           
           
    def calcule_devoir(self,instance):
                try:
                    a_payer = int (self.textinput_payer.text)
                    recu = int(self.inputrecu.text)
                    resultat = recu - a_payer
                    self.inputdevoir.text = f'{resultat}'
                except ValueError:
                    pass
    def tout_suprimer (self,intance) :
          try:
              supression_prdt() 
              ttc= 0
              for stockt in stocktemporaire:
                    total =stockt['total']
                    ttc += total
              self.textinput_payer.text = f"{ttc}"   
              self.textinput_ttc.text = f"{ttc}"
              self.popup.dismiss()
              self.affiche_panier(None)
          except AttributeError:
              pass    
              
    def  validation_caisier(self,instance):
       value = int(self.textinput_ttc.text)
       totals = 0
       for ttc_vent in stocktemporaire:
           totals += ttc_vent['total']
          
       compteur = compteur_caisse()
       nom = print_name()
       
       if totals > value:
           self.interdit = Popup(
           title = 'PAS CONTENT',
           content = Label (
           text = f'{nom}, on ne modifie pas le TTC',
           font_name="Roboto-Bold.ttf"),
           size_hint = (0.8,0.2),
           pos_hint = {'x':0.1,'y':0.4},
            background_color = (0,0,0,0.4),
            background = '')    
           self.interdit.open() 
           
       else :
           printer_test = []
           for i,stockt in enumerate(stocktemporaire):
                id_article = stockt['id_article']
                id_depot = stockt['id_depot']
                code = stockt['code']
                design =stockt['designation']
                quantite =stockt['quantite']
                prix = stockt['prix']
                total =stockt['total'] 
                recette = stockt['recette']     
                savecaisse_data(print_name(),design,quantite,get_times(),prix,total,self.inputrecu.text,self.inputdevoir.text,self.textinputremis.text,compteur,recette,self.inputtype.text)
                reduct_stock(id_article,id_depot,quantite)
                printer_test.append((code,design,quantite,prix,total))

           
           self.labelticket.text = f'Ticket: {compteur}'
           ticket = "ETS :      \n"
                   
           for codes,designs,quantites,prixs,total in printer_test:
                   ticket += f"""      
                 {designs[:24]}
                 {quantites} × {prixs} = {total} \n
                 """
           ticket += f"TOTAL : {totals}\n"
           ticket += f"{self.inputtype.text}\n"
           ticket += f"{totals}\n"
           ticket += f"Remise: {self.textinputremis.text}\n"
           ticket += f"Reçu: {self.inputrecu.text}\n"
           ticket += f"Reste: {self.inputdevoir.text}\n"
           ticket += f"{get_times()}\n"
           ticket += f"op: {print_name()}\n"
           ticket += f"Merci pour votre confiance !\n"
           
           if platform == 'android':
                intent = Intent()
                intent.setAction("com.rawbt.intent.PRINT")
                intent.setPackage("ru.a402d.rawbtprinter")
                intent.putExtra("com.rawbt.intent.extra.DATA", String(ticket))
                PythonActivity.mCurrentActivity.startActivity(intent)
                
           else:
               printer = Win32Raw()
               printer.set(align="center",bold=True)
               printer.text(f"ets: --\n")
               printer.text("-------------------------\n")
               printer.set(align="left")
               for codes,designs,quantites,prixs,total in printer_test:
                    printer.text(f" {quantites}|{designs[:24]}|{prixs}|{total}\n")

               printer.text("-------------------------\n")
               printer.set(bold= False)
               printer.text(f"Total: {totals}f\n")
               printer.text(f"Remise: {self.textinputremis.text}\n")
               printer.text(f"Reçu: {self.inputrecu.text}\n")
               printer.text(f"{self.inputtype.text}\n")
               printer.text(f"Reste: {self.inputdevoir.text}\n")
               printer.text(f"{get_times()}\n")
               printer.text(f"Cassier(e) : {print_name()} \nN°ticket: {compteur}\n")
               printer.text("-------------------------\n")
               printer.text("Merci pour votre confiance.\nà bientot\n")
               printer.cut()
               pass 
           self.inputrecu.text = ''       
           self.inputdevoir.text = ''
           self.textinput_payer.text = ''
           self.shearch_name.text = ''
           self.inputqte.text = '1'    
           supression_prdt()
           ttc= 0
           for stockt in stocktemporaire:
               total =stockt['total']
               ttc += total   
           self.textinput_payer.text = f"{ttc}" 
           self.textinput_ttc.text = f"{ttc}"
           if hasattr(self, 'popup'):
               self.popup.dismiss()
               self.affiche_panier(None)
       