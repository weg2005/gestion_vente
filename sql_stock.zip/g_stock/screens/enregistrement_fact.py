from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Rectangle,Color,RoundedRectangle
from datetime import datetime
from kivy.uix.popup import Popup
from fpdf import FPDF
from kivy.utils import platform
from jnius import autoclass,cast
from database.products import (shearching_depot,update_stock,convert2pdf,get_id_depot)

from logistique.calcule import (add_in_stockt,afficher_stock_fact,add_in_stockt_fact,calcule_montant,supression_prdt)

from database.mouvement_bl import (get_next_fact,print_next_fact,mouvementprint,enregistrement)

from database.connexion import print_name

from database.products import (update_stock,shearch_by_code,print_by_code,shearch_by_design,shearching_depot)

from datetime import datetime
import os
                
def get_times ():
    return datetime.now().strftime('%d-%m-%Y %H:%M:%S')  
    
class Enregistrer_Fact(Screen):
  def __init__(self,**kwargs):
      super(Enregistrer_Fact,self).__init__(**kwargs)
      
      # Boxlayout title
      
      box_title = BoxLayout(
      orientation = 'vertical',
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.84},
      size_hint = (1,0.18))
        
      self.title = Label (text = "SAISI DANS FACTURE\nEnregistrer une facture/FNE",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
      box_title.add_widget (self.title)
      
      box_compteur = BoxLayout(
      padding = 10,
      spacing = 10)
      
      self.facture = Label (text = "N°Fact:",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
        
      box_compteur.add_widget (self.facture)
      
      self.numero_fact = Label (text = f"{print_next_fact()}",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
        
      box_compteur.add_widget(self.numero_fact)
      
      self.boutonretour= Button (
      text = 'Sortir >',
      font_name = 'Roboto-Bold.ttf',
      background_color = (0,0,0,0.),
      background_normal ='')
      
      self.boutonretour.bind(on_press = self.manageretour)
      
      box_compteur.add_widget (self.boutonretour) 
      
      
      box_title.add_widget(box_compteur)
      
      self.add_widget(box_title)
      
      # Boxlayout recherche
      box_rech = BoxLayout(
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.81},
      size_hint = (1,0.07))
        
      self.rech_code = TextInput(
      hint_text = 'recherche ref.',
      background_color = (0,0,0,0.15),
      size_hint = (0.4,1),
      multiline = False,
      foreground_color =(1,1,1,1))
      self.rech_code.bind(text = self.print_in_spinner)
      self.rech_code.bind(on_text_validate = self.get_result2_code )
      box_rech.add_widget(self.rech_code)
        
      self.rech_design = TextInput(
        hint_text = 'recherche par designation',
        background_color = (0,0,0,0.15),
        multiline = False,
        foreground_color =(1,1,1,1))
        
      self.rech_design.bind(text = self.print_in_spin_design)
      self.rech_design.bind(on_text_validate = self.get_result2_design)
     # self.rech_design.bind(on_text_validate= self.print_in_spin_design)
        
            
      
      box_rech.add_widget(self.rech_design)
        
      self.add_widget (box_rech)
        
        # Boxlayout spinner
        
      box_spin = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.78},
        size_hint = (1,0.03))
        
      self.spin_code = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15),
        size_hint = (0.4,1))
        
      box_spin.add_widget(self.spin_code)
        
      self.spin_design = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15))
        
      box_spin.add_widget(self.spin_design)
        
      self.add_widget (box_spin)
      #
      # Boxlayout fournisseur
      box_frs = BoxLayout(
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.71},
      size_hint = (1,0.07))
        
      self.rech_code_frs = TextInput(
        hint_text = 'Reference fournisseur',
        background_color = (0,0,0,0.15),
        size_hint = (0.4,1),
        multiline = False,
        foreground_color =(1,1,1,1))
        
      box_frs.add_widget(self.rech_code_frs)
        
      self.rech_nom = TextInput(
        hint_text = 'Nom du fournisseur',
        background_color = (0,0,0,0.15),
        multiline = False,
        foreground_color =(1,1,1,1))
        
      box_frs.add_widget(self.rech_nom)
        
      self.add_widget (box_frs)
        
        # Boxlayout spinner
        
      box_spin = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.67},
        size_hint = (1,0.02))
        
      self.spin_code_frs = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15),
        size_hint = (0.4,1))
        
      box_spin.add_widget(self.spin_code_frs)
        
      self.spin_nom = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15))
        
      box_spin.add_widget(self.spin_nom)
        
      self.add_widget (box_spin)
      
      # BoxLayout info designation
      
      box_info_d = BoxLayout(
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.61},
      size_hint = (1,0.06))
      
      self.design = TextInput(
      hint_text = "Designation",
      background_color = (0,0,0,0.3),
      font_size = 20,
      font_name = "Roboto-Bold.ttf",
      foreground_color = (1,1,1,1),
      keyboard = False,
      readonly = True,
      allow_copy = False)
      box_info_d.add_widget (self.design)
      
      self.add_widget(box_info_d)
      
      #
      
      box_info = BoxLayout(
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.54},
      size_hint = (1,0.07))
      
      self.stock = Label(
      text = "D_",
      color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf")
      
      box_info.add_widget (self.stock)
      
      self.quantite = TextInput(
      hint_text = "_",
      background_color = (0,0,0,0.3),
      foreground_color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf",
      keyboard = False,
      readonly = True,
      allow_copy = False)
      
      box_info.add_widget (self.quantite)
      
      self.stock_2 = Label(
      text = "D_",
      color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf")
      
      box_info.add_widget (self.stock_2)
      
      self.quantite_2 = TextInput(
      hint_text = "_",
      background_color = (0,0,0,0.3),
      font_size = 20,
      foreground_color = (1,1,1,1),
      font_name = "Roboto-Bold.ttf",
      keyboard = False,
      readonly = True,
      allow_copy = False)
      
      box_info.add_widget (self.quantite_2)
      
      self.stock_3 = Label(
      text = "D_",
      color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf")
      
      box_info.add_widget (self.stock_3)
      
      self.quantite_3 = TextInput(
      hint_text = "_",
      background_color = (0,0,0,0.3),
      foreground_color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf",
      keyboard = False,
      readonly = True,
      allow_copy = False)
      
      box_info.add_widget (self.quantite_3)
      
      self.colis = Label(
      text = "Colis: _ _",
      color = (1,1,1,1),
      font_size = 20,
      font_name = "Roboto-Bold.ttf")
      
      box_info.add_widget (self.colis)
      
      self.add_widget(box_info)
      
        # boxlayout 4 label
        
      box_label = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.24},
        size_hint = (0.3,0.30))
    
      self.label_nom = Label(text = 'Quantité',
        font_name = "Roboto-Bold.ttf")
        
      box_label.add_widget(self.label_nom)
        
      self.label_montant = Label(text = 'Prix achat',
        font_name = "Roboto-Bold.ttf")
        
      box_label.add_widget(self.label_montant)
        
      self.label_ean = Label(text = 'Remise',
        font_name = "Roboto-Bold.ttf")
        
      box_label.add_widget(self.label_ean)
        
      self.label_motif = Label(
        text = 'Montant',
        font_name = "Roboto-Bold.ttf")
        
      box_label.add_widget (self.label_motif)
        
      self.label_type = Label(
        text = 'Type de dépot',
        font_name = "Roboto-Bold.ttf")
        
      box_label.add_widget (self.label_type)
         
      self.add_widget(box_label)
      
      #  boxlayout 4 textinput
      box_textinput = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.5,'y':0.24},
        size_hint = (0.55,0.30))
        
      self.text_quantite = TextInput(hint_text = 'Quantité',
      text = '0',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        multiline = False)
        
      self.text_quantite.bind(on_text_validate = lambda instance : self.next_focus(self.text_achat) )
      
      box_textinput.add_widget(self.text_quantite)
        
      self.text_achat = TextInput(hint_text = 'Prix achat',
      text = '0',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        multiline = False)
        
      self.text_achat.bind(on_text_validate = lambda instance : self.next_focus(self.text_remis) )   
     
      box_textinput.add_widget(self.text_achat)
        
      self.text_remis = TextInput(hint_text = 'Remise',
        text = '0',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        multiline = False)
      
      self.text_remis.bind(on_text_validate = lambda instance : self.next_focus(self.text_montant) )
      
      self.text_remis.bind(on_text_validate = self.ajouter_in_stock )   
     
      box_textinput.add_widget(self.text_remis)
        
      self.text_montant = TextInput(hint_text = "Montant (automatique)",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        multiline = False,
        allow_copy = False,
        keyboard = False,
        readonly = True)
       
      box_textinput.add_widget(self.text_montant)
        
      self.spinner_type = Spinner(
        text = "Type dépot V",
        values = list(shearching_depot()),
        background_normal='',
        background_color=(0, 0, 0, 0.15),  
        font_name = "Roboto-Bold.ttf",
        color =(1,1,1,1),
        font_size = 20)
      self.spinner_type.bind (text = self.variation_prix) 
      box_textinput.add_widget(self.spinner_type)
        

      self.add_widget(box_textinput) 
      
      # Boxlayout comptabilite
      
      box_compt = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.17},
        size_hint = (1,0.07))  
      
      self.HT = TextInput (
      hint_text = 'H.T',
      background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        multiline = False,
        keyboard = False,
        allow_copy = False,
        readonly = True)
        
      box_compt.add_widget (self.HT)  
      
      self.TVA = TextInput (
      hint_text = 'T.V.A',
      background_normal='',
      background_active='',
      background_color=(0, 0, 0, 0.15),  
      foreground_color=(1, 1, 1, 1),
      font_name = "Roboto-Bold.ttf",
      font_size = 20,
      multiline = False,
      keyboard = False,
      readonly= True,
      allow_copy = False)
      
      box_compt.add_widget(self.TVA)      
      
      self.remise = TextInput (
      hint_text = 'Remise',
      text = '0',
      background_normal='',
      background_active='',
      background_color=(0, 0, 0, 0.15),  
      foreground_color=(1, 1, 1, 1),
      font_name = "Roboto-Bold.ttf",
      font_size = 20,
      multiline = False)
      
      
      box_compt.add_widget(self.remise) 
      self.add_widget (box_compt)

      # boxlayout contabilite 2
      
      box_compt_2 = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.07},
        size_hint = (1,0.07))  
      
      self.timbre = TextInput (
      hint_text = 'Timbre',
      text = '0',
      background_normal='',
      background_active='',
      background_color=(0, 0, 0, 0.15),  
      foreground_color=(1, 1, 1, 1),
      font_name = "Roboto-Bold.ttf",
      font_size = 30,
      multiline = False,
      size_hint = (0.4,1)
      )
      box_compt_2.add_widget (self.timbre)
      
      self.montant_c = TextInput (
      hint_text = 'Montant comptable',
      background_normal='',
      text = '0',
      background_active='',
      background_color=(0, 0, 0, 0.15),  
      foreground_color=(1, 1, 1, 1),
      font_name = "Roboto-Bold.ttf",
      font_size = 30,
      multiline = False
      )
        
      box_compt_2.add_widget (self.montant_c)  
      
      self.net_payer = TextInput (
      hint_text = 'Net à payer',
      background_normal='',
      text = '0',
      background_active='',
      background_color=(0, 0, 0, 0.15),  
      foreground_color=(1, 1, 1, 1),
      font_name = "Roboto-Bold.ttf",
      font_size = 30,
      multiline = False,
      keyboard = False,
      allow_copy = False,
      readonly = True)
      
      box_compt_2.add_widget(self.net_payer)  
      self.add_widget (box_compt_2)
      
      # boxlayout action
      
      box_action = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.},
        size_hint = (1,0.07))  
        
      self.button_apercu= Button(
      text = 'Aperçu',
      font_name = "Roboto-Bold.ttf",
      background_color=(0,0.8, 0, 0.6))
      
      self.button_apercu.bind(on_press = self.apercu_fact)
      box_action.add_widget(self.button_apercu)
      
      self.button_valider= Button(
      text = 'Valider',
      font_name = "Roboto-Bold.ttf",
      background_color=(0,0., 0.8, 0.6))
      self.button_valider.bind(on_press = self.validation)
      box_action.add_widget(self.button_valider)
      
      self.add_widget (box_action)
      
      with self.canvas.before:
          self.rect = Rectangle(
          source = fr"{os.path.abspath('assets/images/img_historique.png')}")
          
      def autoposing(*args):
           self.rect.pos = self.pos
           self.rect.size = self.size
          
      self.bind(
        pos = autoposing,
        size = autoposing)
        
  def print_in_spinner(self,instance,text):
      resultat = shearch_by_code(text)
      self.spin_code.values = resultat
      self.spin_code.bind (text =self.send2code_shearch )
      
  def print_in_spin_design(self,instance,text) :
      resultat = shearch_by_design(text)
      self.spin_design.values = resultat
      self.spin_design.bind(text = self.send2design_shearch)
  
  def send2design_shearch(self,instance,text):
      self.rech_design.text = text
      
  def send2code_shearch (self,instance,text):
      self.rech_code.text = text
      
  def get_result2_design(self,instance):
      self.stock.text = ''
      self.quantite.text = ''
      self.stock_2.text = ''
      self.quantite_2.text = ''
      self.stock_3.text = ''
      self.quantite_3.text = ''
      try:
            result = print_by_code(self.rech_design.text)
        
            produit = result[0]
            type_depot = produit[13]
            id_depot = get_id_depot(type_depot)
            self.design.text = str(produit[2])
            self.colis.text = str(produit [7])
            if id_depot == 1:
              self.text_achat.text = str(produit [9])
            else:
                self.text_achat.text = str(produit [8])  
            self.spinner_type.text = str(produit[13])
            depot = []
            quantite = []
            for i,row in enumerate (result) :
                depot.append (row[12])
                quantite.append(row[14])
                
            self.stock.text = f'D{(depot[0])}'
            self.quantite.text = str(quantite[0])
                
            self.stock_2.text = f'D{(depot[1])}'
            self.quantite_2.text = str(quantite[1])
            self.stock_3.text = f'D{(depot[2])}'
            self.quantite_3.text = str(quantite[2])
         
      except IndexError:
            pass
      
  def get_result2_code(self,instance):
      self.stock.text = ''
      self.quantite.text = ''
      self.stock_2.text = ''
      self.quantite_2.text = ''
      self.stock_3.text = ''
      self.quantite_3.text = ''
      try:
            result = print_by_code(self.rech_code.text)
        
            produit = result[0]
            type_depot = produit[13]
            id_depot = get_id_depot(type_depot)
            self.design.text = str(produit[2])
            self.colis.text = str(produit [7])
            if id_depot == 1:
              self.text_achat.text = str(produit [9])
            else:
                self.text_achat.text = str(produit [8])  
            self.spinner_type.text = str(produit[13])
            depot = []
            quantite = []
            for i,row in enumerate (result) :
                depot.append (row[12])
                quantite.append(row[14])
                
            self.stock.text = f'D{(depot[0])}'
            self.quantite.text = str(quantite[0])
                
            self.stock_2.text = f'D{(depot[1])}'
            self.quantite_2.text = str(quantite[1])
            self.stock_3.text = f'D{(depot[2])}'
            self.quantite_3.text = str(quantite[2])
         
      except IndexError:
            pass    
      
  def variation_prix (self,instance,text):
      result = print_by_code(self.rech_design.text)
      produit = result[0]
      id_depot = get_id_depot(text)
      if id_depot == 1:
             self.text_achat.text = str(produit [9])
      else:
             self.text_achat.text = str(produit [8])     

  def  manageretour (self,instance):
        self.manager.current = 'Saisi_Facture'  
  def apercu_fact(self,instance):
        self.manager.current = 'PageImpression_Fact'
        
  def next_focus (self,next_input):
      next_input.focus = True      
      
  def ajouter_in_stock(self,instance):
     result = print_by_code(self.rech_design.text)
     resultat = result[0]
     avant_prix = 0
     net_payer  = 0
     hort_taxe = 0
     taxe_v_a = 0
     try:
         type_depot = self.spinner_type.text
         id_article = resultat[0]
         id_depot = get_id_depot(type_depot)
         code = resultat[1]
         poids = int(resultat[6])
        
         design = self.design.text
         quantite = int (self.text_quantite.text)
         prix_achat = int(self.text_achat.text)
         timbre = int(self.timbre.text)
         remise = int(self.text_remis.text)
         remise_2 = int(self.remise.text)
         colis = int(self.colis.text)
         
         resultat = calcule_montant(quantite,prix_achat,remise)
         
         self.text_montant.text = str(resultat)
         montant = int(self.text_montant.text)
         
         
         add_in_stockt_fact(design,quantite,colis,prix_achat,type_depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant)  
         
         for resultat in afficher_stock_fact():
              avant_prix +=resultat['sous prix']
              net_payer += resultat ['net a payer']
              hort_taxe += resultat ['HT']
              taxe_v_a += resultat ['TVA']
              
              self.montant_c.text = str(avant_prix)
              self.net_payer.text = str(net_payer)
              self.HT.text = str(hort_taxe)
              self.TVA.text = str(taxe_v_a)      
         
         self.design.text = ''
         self.text_quantite.text = ''
     except Exception as e:
          pass
      
              
  def validation(self,instance):
       Poids = 0
       tva = 0
       ht = 0
       net_payer = 0
       for stock in afficher_stock_fact(): 
       
           id_article = stock['id_article']
           id_depot = stock['id_depot']
           quantite = stock['quantite']
           code = stock['code']
           design = stock['designation']
           prix_achat = stock['prix_achat']
           remise = stock['remise']
           montant = stock['montant']
           tva += stock['TVA']
           ht += stock['HT']
           av_prix = stock['sous prix']
           Remise = stock['Remise']
           timbre = stock['timbre']
           net_payer += stock['net a payer']
           depot = stock['depot']
           colis = stock['colis']
           poids = stock['poids'] 
           Poids += poids * quantite
           Poids = Poids 
           
           update_stock (id_article,id_depot,quantite)
           
           enregistrement(print_next_fact(),get_times(),print_name(),code,design,quantite,colis,prix_achat,remise,montant,tva,ht,av_prix,Remise,timbre,net_payer,depot,poids)    
              
       convert2pdf (nom_entreprise = 'Supermarche Petit Paris',telephone = '25672828238',email = 'email@.gmail.com', CDI = 'impôt Abengourou',RC = "",contrib = '',RI = 'REEL NORMAL',BL = f'{print_next_fact()}',frs = self.rech_nom.text ,BP = '225 Abengourou',enregistreur = f'{print_name()}',date = f'{get_times()}',HT = f'{ht}',TVA= f'{tva}',remise = f'{Remise}',net_payer = f'{net_payer}',poids = f'{Poids}',titre = 'FACTURE',text = mouvementprint(print_next_fact()))      

       self.compteur = print_next_fact()

       box_choix = BoxLayout (
                  padding = 30,
                  spacing = 10
              )  
       b_oui = Button(text = "Oui",
                      background_color = (0,0,0,0.3)) 
       b_oui.bind(on_press = self.oui)
       box_choix.add_widget(b_oui)
       
       b_non = Button(text = "Non",
                      background_color = (0,0,0,0.3)) 
       b_non.bind(on_press = lambda instance: self.suces.dismiss())
       box_choix.add_widget(b_non)

       self.suces = Popup(
       title = 'Opperation reussie voulez vous imprimer ?',
       background_color = (0,0,0,0.3),
       content = box_choix,
       size_hint = (0.8,0.2),
       pos_hint = {'x':0.1,'y':0.4})
       self.suces.open()
  
       supression_prdt()
       get_next_fact()
       self.numero_fact.text = f'{print_next_fact()}'   

  def oui(self,instance):
        pdf_path = f"{os.path.abspath(self.compteur)}.pdf"
        if platform == 'android':
            try:
            
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                Intent = autoclass('android.content.Intent')
                Uri = autoclass('android.net.Uri')
                File = autoclass('java.io.File')
                FileProvider = autoclass('androidx.core.content.FileProvider')

                currentActivity = PythonActivity.mCurrentActivity
                context = currentActivity.getApplicationContext()
            
                pdf_file = File(pdf_path)
            
                uri = FileProvider.getUriForFile(
                context,
                context.getPackageName() + ".fileprovider",
                pdf_file
            )

                intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(uri, "application/pdf")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                currentActivity.startActivity(Intent.createChooser(intent, "Ouvrir PDF"))
            
            except Exception as e:
                print(f"Erreur ouverture PDF: {e}")
        else:
            os.startfile(pdf_path)
        
        self.suces.dismiss()