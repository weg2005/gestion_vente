from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner
from kivy.graphics import Rectangle, RoundedRectangle,Color
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
import os
class CreationCompteVers(Screen):
    def __init__(self,**kwargs):
        super(CreationCompteVers,self).__init__(**kwargs)
        
        #boxlayout 4 title 
        box_title = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.75},
        size_hint = (1,0.2))
        
        self.title = Label (text = "NOUVEAU COMPTE\nEnregistrer un nouveau compte",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
        box_title.add_widget (self.title)
        self.add_widget(box_title)
        
        # boxlayout 4 label
        
        box_label = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.23},
        size_hint = (0.5,0.5))
    
        self.label_nom = Label(text = 'Nom/Prenoms',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_nom)
        
        self.label_montant = Label(text = 'Numero de contact',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_montant)
        
        self.label_motif = Label(
        text = 'Email',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_motif)
        
        self.label_adresse = Label(
        text = 'Localité/addresse',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_adresse)
        
        self.label_contrib = Label(
        text = 'Compte contribuable',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_contrib)
        
        self.label_type = Label(
        text = 'Type de client',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_type)
        
        self.label_type = Label(
        text = "Date de création",
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_type)
        
        self.add_widget(box_label)
        #=====================
        #  boxlayout 4 textinput
        box_textinput = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.5,'y':0.23},
        size_hint = (0.5,0.5))
        
        self.text_nom = TextInput(hint_text = 'Entrez un nom\nClient',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
       
        box_textinput.add_widget(self.text_nom)
        
        self.text_montant = TextInput(hint_text = 'Entrez le numero\n12345678910',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
       
        box_textinput.add_widget(self.text_montant)
        
        self.text_motif = TextInput(hint_text = "Entrez l'Email\nemail@.com",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
       
        box_textinput.add_widget(self.text_motif)
        
        self.text_adresse = TextInput(hint_text = "Entrez ici la localité",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
       
        box_textinput.add_widget(self.text_adresse)
        
        self.text_comp = TextInput(hint_text = "Entrez ici le compte\ncontribuable",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
       
        box_textinput.add_widget(self.text_comp)
        
        self.spinner_type = Spinner(text = "Cliquez \/",
        values = ['Particulier','Entreprise'],
        border = (0,0,0,0),
        background_normal='',
        background_down = '',
        background_color=(1, 1, 1, 0),  
        color=(1, 1, 1, 0.4),
        font_name = "Roboto-Bold.ttf",
        font_size = 30)
       
        box_textinput.add_widget(self.spinner_type)
        
        self.text_date = TextInput(hint_text = "Date du jour",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        multiline = False)
        box_textinput.add_widget(self.text_date)
        self.add_widget(box_textinput) 
        
         #========================
        # boxlayouts 4 actions
        # box 4 left
        
        box_left = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.02},
        size_hint = (0.4,0.07))
        
        self.anuler = Button(
        text = 'Annuler',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 40)
        self.anuler.bind (on_press = self.retour_vers)
        box_left.add_widget (self.anuler)
        self.add_widget(box_left)
        #======================
        # box 4 right
        box_right = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.55,'y':0.02},
        size_hint = (0.4,0.07))
        
        self.valider = Button(
        text = 'Valider',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 30)
        
        box_right.add_widget (self.valider)
        self.add_widget(box_right)
        
        with self.canvas.before:
            self.rect_screen = Rectangle(
            source = f"{os.path.abspath('assets/images/img_compte.png')}")
        def background_screen (*args):
            self.rect_screen.pos = self.pos
            self.rect_screen.size = self.size
            
        self.bind(
         pos = background_screen,
         size = background_screen)   
         
        with box_textinput.canvas.before:
            Color (0.5,0,0.5,0.4)
            self.roun_nom =RoundedRectangle( )
        def resize_function_nom (*args):
            self.roun_nom.pos = box_textinput.pos
            self.roun_nom.size = box_textinput.size
         
        box_textinput.bind(
        pos= resize_function_nom,
        size = resize_function_nom)
        
        with box_textinput.canvas.before:
            Color (0.2,0,0.6,0.5)
            self.roun_input =RoundedRectangle( )
        def resize_function_note (*args):
            self.roun_input.pos = box_textinput.pos
            self.roun_input.size = box_textinput.size
         
        box_textinput.bind(
        pos= resize_function_note,
        size = resize_function_note)
        
        with box_title.canvas.before:
            Color (0.5,0,0.6,0.4)
            self.roun_title =RoundedRectangle( )
        def resize_function_title (*args):
            self.roun_title.pos = box_title.pos
            self.roun_title.size = box_title.size
         
        box_title.bind(
        pos= resize_function_title,
        size = resize_function_title)
        
        with box_label.canvas.before:
            Color (0.2,0,0.6,0.4)
            self.roun_label =RoundedRectangle( )
        def resize_function_label (*args):
            self.roun_label.pos = box_label.pos
            self.roun_label.size = box_label.size
         
        box_label.bind(
        pos= resize_function_label,
        size = resize_function_label)
        
        with box_left.canvas.before:
            Color (0.8,0,0.,0.60)
            self.roun_left =RoundedRectangle( )
        def resize_function_left (*args):
            self.roun_left.pos = box_left.pos
            self.roun_left.size = box_left.size
         
        box_left.bind(
        pos= resize_function_left,
        size = resize_function_left)
        
        with box_right.canvas.before:
            Color (0.,0.8,0.,0.60)
            self.roun_right =RoundedRectangle( )
        def resize_function_right (*args):
            self.roun_right.pos = box_right.pos
            self.roun_right.size = box_right.size
         
        box_right.bind(
        pos= resize_function_right,
        size = resize_function_right)
         
    def retour_vers(self,instance):
        self.manager.current = "ScreenVersement"       