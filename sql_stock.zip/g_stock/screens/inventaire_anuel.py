# screens/inventaire tournant

from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color,Rectangle,RoundedRectangle
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup

from logistique.calcule import add_in_stockt_sbl,afficher_stock_sbl,calcule_montant,supression_prdt_sbl
from datetime import datetime
import os

def get_times ():
    return datetime.now().strftime('%d-%m-%Y %H:%M:%S')

class InventaireAnuel(Screen):
    def __init__(self, **kwargs):
        super(InventaireAnuel, self).__init__(**kwargs)
        pass