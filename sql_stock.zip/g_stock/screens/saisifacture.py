from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Rectangle,Color,RoundedRectangle
from datetime import datetime
from kivy.uix.popup import Popup
from fpdf import FPDF
import os

class SaisiFacture(Screen):
  def __init__(self,**kwargs):
      super(SaisiFacture,self).__init__(**kwargs)
      
      # Boxlayout title
      
      box_title = BoxLayout(
      orientation = 'vertical',
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.8},
      size_hint = (1,0.2))
        
      self.title = Label (text = "SAISI DE FACTURE\nSaisir une nouvelle facture",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
      box_title.add_widget (self.title)
        
      self.boutonretour= Button (
      text = 'Sortir >',
      font_name = 'Roboto-Bold.ttf',
      background_color = (0,0,0,0.15),
      background_normal ='')
      
      box_title.add_widget (self.boutonretour) 
      self.boutonretour.bind (on_press = self.manageretour)
      self.add_widget(box_title)
      
      # boxlayout liste
      box_action = BoxLayout (
      orientation = "vertical",
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.4},
      size_hint = (1,0.45))
      
      self.title_2 = Label (text = "Entrer en stock",
        color = (1,1,1,1),
        font_size = 30,
        font_name = "Roboto-Bold.ttf")
      box_action.add_widget (self.title_2)
        
      self.button_saisi = Button(
      text = "Creer un article",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      
      self.button_saisi.bind (on_press = self.open_saisi)
      box_action.add_widget(self.button_saisi)

        # bouton pour facture
      self.button_facture = Button(
      text = "Saisi de Bon de Livraison",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      self.button_facture.bind (on_press = self.saisi_BL)  
      box_action.add_widget(self.button_facture)
        # bouton de commande
      self.button_fact = Button(
      text = "Saisi Facture Manuel/FNE",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      
      box_action.add_widget(self.button_fact)
      
      self.button_fact.bind(on_press = self.saisi_fact)
      
      self.add_widget (box_action)
        # boxlayout liste 2
        
      box_liste = BoxLayout (
      orientation = "vertical",
      padding = 10,
      spacing = 10,
      pos_hint = {'x':0.,'y':0.},
      size_hint = (1,0.4))
      
      self.title_2 = Label (text = "Sorti de stock",
        color = (1,1,1,1),
        font_size = 30,
        font_name = "Roboto-Bold.ttf")
      box_liste.add_widget (self.title_2)
        
      self.button_saisi = Button(
      text = "Saisi de FNE",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      self.button_saisi.bind(on_press = self.fne_sorti)
      box_liste.add_widget(self.button_saisi)

        # bouton pour facture
      self.button_facture = Button(
      text = "Saisi de Bon de Livraison",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf")
      self.button_facture.bind(on_press = self.bl_sorti) 
      box_liste.add_widget(self.button_facture)
        # bouton de commande
      self.button_commande = Button(
      text = "Saisi de Proforma",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      box_liste.add_widget(self.button_commande)
      self.button_commande.bind(on_press =self.pr_sorti )
          
      self.button_avoir = Button(
      text = "Avoir sur facture",
      background_color = (0,0,0,0.15), 
      background_normal ='',
      background_down = "",
      font_name = "Roboto-Bold.ttf" )
      box_liste.add_widget(self.button_avoir)
      
      self.button_avoir.bind(on_press = self.avoir_sorti)
    
      self.add_widget (box_liste)
        
      with self.canvas.before:
          self.rect = Rectangle(
          source = fr"{os.path.abspath('assets/images/file_0000000074f07246a51a0f9ce144e4e3.png')}")
          
      def autoresizing(*args):
          self.rect.pos = self.pos
          self.rect.size = self.size
          
      self.bind(
      pos = autoresizing,
      size = autoresizing)
    
    
  def open_saisi(self,instance):
        self.manager.current = 'CreerArticle'      
  def  manageretour (self,instance):
        self.manager.current = 'acceil'   
        
  def  saisi_BL (self,instance):
        self.manager.current = 'Enregistrer_BL'   
        
  def  saisi_fact (self,instance):
        self.manager.current = 'Enregistrer_Fact'  
        
  def fne_sorti (self,instance):
       self.manager.current = 'SortiFNE'     
       
  def bl_sorti(self,instance):
       self.manager.current = 'SortiBL'    
       
  def pr_sorti(self,instance):
      self.manager.current = 'SortiPR'    
      
  def  avoir_sorti (self,instance):
      self.manager.current = 'AvoirFacture'