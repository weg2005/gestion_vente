# screens/connexion.py
from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.graphics import Color, RoundedRectangle,Rectangle
from kivy.uix.boxlayout import BoxLayout
from database.user_db import get_user
from database.connexion import (save_name,print_name,name_deleded)
import os

class PageConnexion(Screen):
    def __init__(self, **kwargs):
        super(PageConnexion, self).__init__(**kwargs)
        
        self.compter = 0
        #boxlayout 4 title 
        box_title = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.75},
        size_hint = (1,0.2))
        
        self.title = Label (text = "SE CONNECTER\nConnectez-vous pour entrer",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
        box_title.add_widget (self.title)
        self.add_widget(box_title)
        
        # Boxlayout for connexion
        
        box_connexion = BoxLayout(
        orientation ='vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.1,'y':0.3},
        size_hint = (0.8,0.4))
        # Label nom
        self.titre_nom = Label(
        text="Nom d'utilisateur",
        color =(1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 35)
        box_connexion.add_widget(self.titre_nom)

        self.inserer_nom = TextInput(
        hint_text = "Entrez ici le nom",
        foreground_color =(1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 35,
        background_active = "",
        background_normal = "",
        background_color = (0,0,0,0),
        multiline = False)
        box_connexion.add_widget(self.inserer_nom)

        # Label mot de passe
        self.titre_passe = Label(
        text='Mot de passe',
        color =(1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 35)
        box_connexion.add_widget(self.titre_passe)

        self.saisi_passe = TextInput( 
        multiline=False, 
        password=True, 
        password_mask = '•',
        hint_text = "Entrez ici le mot de passe",
        foreground_color =(1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        font_size = 40,
        background_active = "",
        background_normal = "",
        background_color = (0,0,0,0))
        box_connexion.add_widget(self.saisi_passe)
        
        self.add_widget (box_connexion)
        
        # Bouton action
        box_left = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.08},
        size_hint = (0.4,0.07))
        
        self.anuler = Button(
        text = 'Annuler',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 40)
        box_left.add_widget (self.anuler)
        self.add_widget(box_left)
        #======================
        # box 4 right
        box_right = BoxLayout (
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.55,'y':0.08},
        size_hint = (0.4,0.07))
        
        self.valider = Button(
        text = 'Se connecter',
        background_normal ="",
        background_down ='',
        color = (1,1,1,1),
        background_color = (0,0,0,0),
        font_name = "Roboto-Bold.ttf",
        font_size = 40)
        
        box_right.add_widget (self.valider)
        self.add_widget(box_right)
        self.valider.bind(on_press = self.controlleur)
        
        # Alerte label
        box_alerte = BoxLayout (
        orientation = "vertical",
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.05,'y':0.17},
        size_hint = (0.9,0.1))
        
        self.errer_sql = Label (
        text = "",
        color = (1,1,1,1),
        font_name= "Roboto-Bold.ttf"
        )
        box_alerte.add_widget (self.errer_sql)
        self.add_widget (box_alerte)

        # Image fond
        with self.canvas.before:
            
            self.img_c = Rectangle(source=fr"{os.path.abspath('assets/images/img_connexion.png')}", size=self.size, pos=self.pos)
        self.bind(size=self.update_img, pos=self.update_img)
        
        with box_left.canvas.before:
            Color (0.8,0,0.,0.60)
            self.roun_left =RoundedRectangle( )
        def resize_function_left (*args):
            self.roun_left.pos = box_left.pos
            self.roun_left.size = box_left.size
         
        box_left.bind(
        pos= resize_function_left,
        size = resize_function_left)
        
        with box_right.canvas.before:
            Color (0.,0.8,0.,0.60)
            self.roun_right =RoundedRectangle( )
        def resize_function_right (*args):
            self.roun_right.pos = box_right.pos
            self.roun_right.size = box_right.size
         
        box_right.bind(
        pos= resize_function_right,
        size = resize_function_right)
        
        with box_alerte.canvas.before:
                Color (0.8,0.,0.,0.15)
                self.roun_alerte =RoundedRectangle( )
        def resize_function_alerte (*args):
                self.roun_alerte.pos = box_alerte.pos
                self.roun_alerte.size = box_alerte.size
         
        box_alerte.bind(
        pos= resize_function_alerte,
        size = resize_function_alerte)      
        
        with box_connexion.canvas.before:
            Color (5,0.,0.6,0.2)
            self.rect_connexion = RoundedRectangle(raduis = [100])
            
        def update_bg_connexion (*args):
            self.rect_connexion.pos = box_connexion.pos
            self.rect_connexion.size = box_connexion.size
         
        box_connexion.bind(
        pos = update_bg_connexion,
        size = update_bg_connexion)         

    def update_img(self, *args):
        self.img_c.size = self.size
        self.img_c.pos = self.pos
        

    def controlleur(self, instance):
        """Vérifie les identifiants et limite à 3 tentatives."""
           
        self.userconnexion = get_user(self.inserer_nom.text, self.saisi_passe.text)
        if self.userconnexion:
            role = self.userconnexion[4]
            name_deleded()
            save_name(self.inserer_nom.text)
            if role == 'Caissier':
                self.manager.current = 'page_caisse'
            self.manager.current = 'acceil'
            
        else:
            self.compter += 1
            
            self.errer_sql.text = f'UTILIASTEUR NON RECONNU  {self.compter}/3\nLe logiciel se fermera à la 3ème tantative'
            
            if self.compter > 3:
                from kivy.app import App
                App.get_running_app().stop()
                
   
                       