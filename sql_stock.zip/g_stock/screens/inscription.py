# screens/inscription.py
from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle
from database.user_db import add_user

class PageInscription(Screen):
    def __init__(self, **kwargs):
        super(PageInscription, self).__init__(**kwargs)

        # Label pour nom
        self.instruct_nom = Label(text='Inscrivez votre nom', pos_hint={'x':0.0, 'y':0.8},
                                  size_hint=(1, 0.05), color=(0, 1, 0, 1))
        self.add_widget(self.instruct_nom)

        # Champ nom
        self.champ_nom = TextInput(size_hint=(0.75, 0.05), pos_hint={'x':0.1, 'y':0.75}, multiline=False)
        self.add_widget(self.champ_nom)

        # Label pour mot de passe
        self.instruct_passe = Label(text='Mot de passe', pos_hint={'x':0.0, 'y':0.60},
                                    size_hint=(1, 0.05), color=(0, 1, 0, 1))
        self.add_widget(self.instruct_passe)

        # Champ mot de passe
        self.mot_passe = TextInput(size_hint=(0.8, 0.05), pos_hint={'x':0.1, 'y':0.55}, multiline=False, password=True)
        self.add_widget(self.mot_passe)

        # Label pour rôle
        self.instruct_role = Label(text='Rôle', pos_hint={'x':0.0, 'y':0.40},
                                   size_hint=(1, 0.05), color=(0, 1, 0, 1))
        self.add_widget(self.instruct_role)

        # Liste des rôles
        self.list_roles = Spinner(text='Roles', values=('Admin','sous-Admin' ,'Magasinier', 'Caissier'),
                                  size_hint=(0.5, 0.05), pos_hint={'x':0.25, 'y':0.35},
                                  background_color=(0, 0, 0, 1), background_normal='')
        self.add_widget(self.list_roles)

        # Bouton pour créer le compte
        self.creer_compte = Button(text='Créer le compte', pos_hint={'x':0.25, 'y':0.2},
                                   size_hint=(0.5, 0.05), background_color=(0, 1, 0, 1),
                                   background_normal='')
        self.creer_compte.bind(on_press=self.enregistrer_compte)
        self.add_widget(self.creer_compte)

        # Image de fond
        with self.canvas.before:
            self.img = Rectangle(source="/storage/emulated/0/gestion_vente/assets/images/vector-follow-add-user-icon-600nw-2268281559.jpg", size=self.size, pos=self.pos)
        self.bind(size=self.update_bg, pos=self.update_bg)

    def update_bg(self, *args):
        self.img.size = self.size
        self.img.pos = self.pos

    def enregistrer_compte(self, instance):
        """Enregistre le compte et passe à la page de connexion."""
        add_user(self.champ_nom.text, self.mot_passe.text, self.list_roles.text)
        self.champ_nom.text = ''
        self.mot_passe.text = ''
        self.manager.current = 'connexion'