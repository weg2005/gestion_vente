from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Rectangle,Color,RoundedRectangle
from database.connexion import print_name
from kivy.uix.scrollview import ScrollView
from datetime import datetime
from kivy.uix.popup import Popup
from fpdf import FPDF
from database.products import (shearching_depot)
from logistique.calcule import (add_in_stockt,afficher_stock,calcule_montant)
from database.products import (update_stock,shearch_by_code,print_by_code,shearch_by_design,shearching_depot)
from database.mouvement_bl import print_next_bl
import os
class PageImpression_BL(Screen):
    
    def on_pre_enter(self):
        self.refresh_list()

    def refresh_list(self):
        
        box_title = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.85},
        size_hint = (1,0.15))
    
        title = Label (text = f"Bon de Libraison\nEnregistreur : {print_name()}\nN°BL: {print_next_bl()}",
        color = (1,1,1,1),
        font_size = 35,
        font_name = "Roboto-Bold.ttf")
        
        box_title.add_widget (title) 
        
        bouton_sorti= Button (text = f"Sorti >",
        color = (1,1,1,1),
        font_size = 35,
        font_name = "Roboto-Bold.ttf",
        background_color = (0,0,0,0),
        size_hint = (0.5,1))
        
        box_title.add_widget (bouton_sorti)
        
        hearder = BoxLayout(
        pos_hint = {'x':0.,'y':0.78},
        size_hint = (1,0.07))
        
        hearder.add_widget(Label(text = 'CODE',font_name='Roboto-Bold.ttf',
        color = (1,1,1,1)
        ))
        
        hearder.add_widget(Label(text = 'DESIGNATION',font_name='Roboto-Bold.ttf',
        color = (1,1,1,1)))
        hearder.add_widget(Label(text = 'QUANTITE',font_name='Roboto-Bold.ttf',
        color = (1,1,1,1)))
        
        hearder.add_widget(Label(text = 'PRIX',font_name='Roboto-Bold.ttf',
        color = (1,1,1,1)))
        
        hearder.add_widget(Label(text = 'REMISE',font_name='Roboto-Bold.ttf',
        color =(1,1,1,1)))
        
        hearder.add_widget(Label(text = 'MONTANT',font_name='Roboto-Bold.ttf',color = (1,1,1,1)))
        
        hearder_2 = BoxLayout(
        pos_hint = {'x':0.,'y':0.1},
        size_hint = (1,0.07))
        
        hearder_2.add_widget(Label(text = 'H.TAXE',font_name='Roboto-Bold.ttf',
        color = (1,1,1,1)))
        
        hearder_2.add_widget(Label(text = 'T.V.A',font_name='Roboto-Bold.ttf',
        color =(1,1,1,1)))
        
        hearder_2.add_widget(Label(text = 'POIDS',font_name='Roboto-Bold.ttf',
        color =(1,1,1,1)))
        
        hearder_2.add_widget(Label(text = 'REMISE',font_name='Roboto-Bold.ttf',color = (1,1,1,1)))
        
        hearder_2.add_widget(Label(text = 'NET À PAYER',font_name='Roboto-Bold.ttf',color = (1,1,1,1)))
        
        
        
        self.clear_widgets()
        
 
        scroll = ScrollView(
        size_hint = (1,0.55),
        pos_hint = {'x':0.,'y':0.2})

        box = BoxLayout(
            padding=10,
            spacing=10,
            size_hint_y=None,
            orientation='vertical'
        )

        box.bind(minimum_height=box.setter('height'))
        
        net_payer  = 0
        hort_taxe = 0
        taxe_v_a = 0
        remise = 0
        poids = 0
        values = BoxLayout(
        pos_hint = {'x':0.,'y':0.0},
        size_hint = (1,0.07))
         
        for result in afficher_stock():
            
            net_payer += result ['net a payer']
            hort_taxe += result ['HT']
            taxe_v_a += result ['TVA']
            remise += result['Remise']
            poids += result['poids'] * result['quantite']
            
            box_liste = BoxLayout(
            padding=10,
            spacing=10,
            size_hint_y = None
        )   
            
            box_liste.add_widget(Label(text =f"{result['code']}" ,
            size_hint_y = None))
            
            box_liste.add_widget(Label(text =f"{result['designation']}" ,
            size_hint_y = None))
            
            box_liste.add_widget(Label(text =f"{result['quantite']}" ,
            size_hint_y = None))
            
            box_liste.add_widget(Label(text =f"{result['prix_achat']}" ,
            size_hint_y = None))
            
            box_liste.add_widget(Label(text =f"{result['remise']}" ,
            size_hint_y = None))
            
            box_liste.add_widget(Label(text =f"{result['montant']}" ,
            size_hint_y = None))
            
            box.add_widget(box_liste)
            
        values.add_widget(Label(text = f'{hort_taxe}',font_name='Roboto-Bold.ttf',
            color = (1,1,1,1)))
            
        values.add_widget(Label(text = f'{taxe_v_a}',font_name='Roboto-Bold.ttf',
            color =(1,1,1,1)))
         
        values.add_widget(Label(text = f'{poids}',font_name='Roboto-Bold.ttf',color = (1,1,1,1)))  
            
        values.add_widget(Label(text = f'{remise}',font_name='Roboto-Bold.ttf',color = (1,1,1,1)))
            
        values.add_widget(Label(text = f'{net_payer}',font_name='Roboto-Bold.ttf',color = (1,1,1,1))) 
        
        bouton_sorti.bind(on_press = self.retour_bl)
        
        self.add_widget (values)
        
        scroll.add_widget(box)
        
        self.add_widget(scroll)
        
        self.add_widget(box_title)
        
        self.add_widget(hearder)
        
        self.add_widget(hearder_2)
       
        with self.canvas.before:
          
          self.rect = Rectangle(
          source = fr"{os.path.abspath('assets/images/file_0000000074f07246a51a0f9ce144e4e3.png')}")
          
        def autoposing(*args):
           self.rect.pos = self.pos
           self.rect.size = self.size
          
        self.bind(
          pos = autoposing,
          size = autoposing)    
          
    def retour_bl(self,instance):
            self.manager.current = 'Enregistrer_BL'          
         