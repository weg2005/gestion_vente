# screens/acceil.py
import os
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.graphics import Color,Rectangle

class PageAcceil(Screen):
    def __init__(self, **kwargs):
        super(PageAcceil, self).__init__(**kwargs)
        box_title = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.78},
        size_hint = (1,0.2))
        
        self.title = Label (text = "MENU\nBienvenu(e) dans le gestionaire de stock\nVous êtes perdu(e)s ? \nCliquez sur le 'Manuel d'utilisation'",
        color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf")
        box_title.add_widget (self.title)
        
        self.manuel = Button (
        text = "Manuel d'utilisation >",
        background_color = (0,0,0,0.05), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf",
     )
        box_title.add_widget (self.manuel)
        self.add_widget(box_title)
        
        # ACTION SUR SKOCK
        box_action = BoxLayout (
        orientation = "vertical",
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.05},
        size_hint = (1,0.7))
        
        self.button_saisi = Button(
        text = "Caisse",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf")
        box_action.add_widget(self.button_saisi)
        self.button_saisi.bind(on_press = self.caisse )
        # bouton pour facture
        self.button_facture = Button(
        text = "Saisi de factures",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf")
        self.button_facture.bind(on_press = self.saisi_facture)
        box_action.add_widget(self.button_facture)
        # bouton de commande
        self.button_gestion = Button(
        text = "Gestion de stock",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf" )
        
        self.button_gestion.bind(on_press = self.gestion_stock )
        
        box_action.add_widget(self.button_gestion)
        # button de comptabilité
        self.button_tableau = Button(
        text = "Tableau de bord",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf")
        box_action.add_widget(self.button_tableau)
        self.button_tableau.bind(on_press = self.tableau_bord)
        # button d'inventaire
        self.button_inventaire = Button(
        text = "Bien etre de l'entreprise",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf")
        box_action.add_widget(self.button_inventaire)
         # button d'historique
        self.button_historique = Button(
        text = "Journal de stock",
        background_color = (0,0,0,0.15), 
        background_normal ='',
        background_down = "",
        font_name = "Roboto-Bold.ttf")
        box_action.add_widget(self.button_historique)
        self.add_widget (box_action)
        
        with self.canvas.before:
            source = os.path.abspath('assets/images/file_0000000074f07246a51a0f9ce144e4e3.png')
            self.arriere_plan = Rectangle(
            size= self.size,
            pos= self.pos,
            source = f'{source}')
        self.bind (
        size = self.up_img,
        pos = self.up_img)
        
    def up_img (self,*args):
         self.arriere_plan.size = self.size
         self.arriere_plan.pos = self.pos
         
    def caisse  (self,instance):
         self.manager.current = 'page_caisse'    
    def saisi_facture (self,instance):
         self.manager.current = 'Saisi_Facture'         
         
    def tableau_bord (self,instance) :
         self.manager.current = "TableauBord"
         
    def  gestion_stock(self,instance):
        self.manager.current = 'GestionStock'