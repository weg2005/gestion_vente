from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Rectangle,Color,RoundedRectangle
from datetime import datetime
from kivy.uix.popup import Popup
from logistique.calcule import (trouver_prix_d,proposer_prix_colis,proposer_prix_detail)

from database.products import (save_products,update_stock,shearch_by_code,print_by_code,shearch_by_design,shearching_depot,save_depot,modification,suppression)
from datetime import datetime
import os
def get_times ():
    return datetime.now().strftime('%d-%m-%Y %H:%M:%S')
    
class CreerArticle(Screen):
  def __init__(self,**kwargs):
        super(CreerArticle,self).__init__(**kwargs)

      #boxlayout 4 title 
        box_title = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.9},
        size_hint = (1,0.1))
        
        self.title = Label (text = "NOUVEL ARTICLE\nEnregistrer un nouvel article",
        color = (1,1,1,1),
        font_size = 40,
        font_name = "Roboto-Bold.ttf")
        box_title.add_widget (self.title)
        self.add_widget(box_title)
        
        # Boxlayout recherche
        
        box_rech = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.82},
        size_hint = (1,0.07))
        
        self.rech_code = TextInput(
        hint_text = 'recherche ref.',
        background_color = (0,0,0,0.15),
        size_hint = (0.4,1),
        multiline = False,
        foreground_color =(1,1,1,1))
        
        self.rech_code.bind (text = self.sheach_code )
        
        self.rech_code.bind (on_text_validate = self.print_values_code)
        
        box_rech.add_widget(self.rech_code)
        
        self.rech_design = TextInput(
        hint_text = 'recherche par designation',
        background_color = (0,0,0,0.15),
        multiline = False,
        foreground_color =(1,1,1,1))
        self.rech_design.bind(text = self.shearch_designation)
        
        self.rech_design.bind(on_text_validate = self.print_values_design)
        
        box_rech.add_widget(self.rech_design)
        
        self.add_widget (box_rech)
        
        #
        
        box_spin = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.78},
        size_hint = (1,0.05))
        
        self.spin_code = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15),
        size_hint = (0.4,1))
        
        box_spin.add_widget(self.spin_code)
        
        self.spin_design = Spinner(
        text = 'v',
        background_color = (0,0,0,0.15))
        
        box_spin.add_widget(self.spin_design)
        
        self.add_widget (box_spin)
        # boxlayout 4 label
        
        box_label = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.43},
        size_hint = (0.3,0.35))
    
        self.label_nom = Label(text = 'Reference',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_nom)
        
        self.label_montant = Label(text = 'Designation',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_montant)
        
        self.label_ean = Label(text = 'Code EAN',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget(self.label_ean)
        
        self.label_motif = Label(
        text = 'Categorie',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_motif)
        
        self.label_type = Label(
        text = 'S.categorie',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_type)
        
        self.label_poids = Label(
        text = 'Poids',
        font_name = "Roboto-Bold.ttf")
        
        box_label.add_widget (self.label_poids)
          
        self.add_widget(box_label)
        #=====================
        #  boxlayout 4 textinput
        box_textinput = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.5,'y':0.4},
        size_hint = (0.55,0.38))
        
        self.text_ref = TextInput(hint_text = 'Entrez une reference\n12345',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.3),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
        
        self.text_ref.bind(on_text_validate =lambda instance: self.next_focus (self.text_design))
        
        box_textinput.add_widget(self.text_ref)
        
        self.text_design = TextInput(hint_text = 'Entrez une designation\nProduit',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.3),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
        
        self.text_design.bind(on_text_validate =lambda instance: self.next_focus (self.text_ean))
        
        box_textinput.add_widget(self.text_design)
        
        self.text_ean = TextInput(hint_text = 'Entrez un code barre\n12345678910111213',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.3),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
        
        self.text_ean.bind(on_text_validate =lambda instance: self.next_focus (self.text_categ))
       
        box_textinput.add_widget(self.text_ean)
        
        self.text_categ = TextInput(hint_text = "Entrez sa categorie\nAlimentation",
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.3),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
        
        self.text_categ.bind(on_text_validate =lambda instance: self.next_focus (self.text_sfamille))
       
        box_textinput.add_widget(self.text_categ)
        
        self.text_sfamille = TextInput(
        hint_text = "Sa sous categotie\nbiscuit",
        background_normal='',
        background_color=(0, 0, 0, 0.3),  
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1),
        font_size = 30)
        
        self.text_sfamille.bind(on_text_validate =lambda instance: self.next_focus (self.text_poids))
       
        box_textinput.add_widget(self.text_sfamille)
        
        self.text_poids = TextInput(
        hint_text = "Poids du produit\nen kilo gramme",
        background_normal='',
        background_color=(0, 0, 0, 0.3),  
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1),
        font_size = 30)
        
        self.text_poids.bind(on_text_validate =lambda instance: self.next_focus (self.colis))
       
        box_textinput.add_widget(self.text_poids)
        
        self.add_widget(box_textinput) 
        
        # boxlayout comptabitite
        # boxlayout achat
        box_hor = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.15},
        size_hint = (0.5,0.25))
        
        self.colis = TextInput(
        hint_text = 'Colisage',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        box_hor.add_widget(self.colis)
        
        self.colis.bind(on_text_validate =lambda instance: self.next_focus (self.prix_achat))
        
        
        
        self.prix_achat = TextInput(
        hint_text = 'Prix achat',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        box_hor.add_widget(self.prix_achat)
        
        self.prix_achat.bind(on_text_validate =lambda instance: self.next_focus (self.prix_achat_detail))
        
        self.prix_achat.bind(on_text_validate = self.proposition_prix_colis)        
        
        self.prix_achat_detail = TextInput(
        hint_text = 'Prix detail achat',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        box_hor.add_widget(self.prix_achat_detail)
        
        self.prix_achat_detail.bind(on_text_validate =lambda instance: self.next_focus (self.colis_vente))
        
        self.add_widget(box_hor)
        
        # boxlayout vente
       
        box_vent = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.5,'y':0.15},
        size_hint = (0.5,0.25))
        
        box_prix_c = BoxLayout (
        padding= 10,
        spacing = 10)
        
        self.colis_vente = TextInput(
        hint_text = 'Prix colis vente',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        
        box_prix_c.add_widget(self.colis_vente)
        
        self.pourcentage_c = TextInput(
        text = '20',
        hint_text = '%',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1),
        size_hint = (0.5,1))
        
        box_prix_c.add_widget(self.pourcentage_c)
        
        box_vent.add_widget(box_prix_c)
        
        self.colis_vente.bind(on_text_validate =lambda instance: self.next_focus (self.prix_detail_v))
        
        box_prix_d = BoxLayout (
        padding= 10,
        spacing = 10)
        
        self.prix_detail_v = TextInput(
        hint_text = 'Prix detail vente',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        
        box_prix_d.add_widget(self.prix_detail_v)
        
        self.pourcentage_d = TextInput(
        text = '20',
        hint_text = '%',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1),
        size_hint = (0.5,1))
        
        box_prix_d.add_widget(self.pourcentage_d)
        
        box_vent.add_widget(box_prix_d)
        
        self.prix_detail_v.bind(on_text_validate =lambda instance: self.next_focus (self.type_stock))
        
        box_button = BoxLayout (
        padding= 10,
        spacing = 10)
        
        self.type_stock = TextInput(
        hint_text = 'Stock',
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        background_color = (0,0,0,0.15),
        foreground_color = (1,1,1,1))
        self.type_stock.bind(text = self.shearch_depot)
        
        self.type_stock.bind(on_text_validate =lambda instance: self.next_focus (self.text_ref))
        
        box_button.add_widget(self.type_stock)
        
        box_vent.add_widget(box_button)
        
        self.depot_type = Spinner(
        text = 'v',
        font_name = "Roboto-Bold.ttf",
        background_color = (0,0,0,0.15),
        size_hint = (1,0.4))
        box_vent.add_widget(self.depot_type)
        
        self.add_widget(box_vent)
        
        #
        
        box_val = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.07},
        size_hint = (1,0.08))
        
        self.button_ajouter = Button(
        text= 'Modifier',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,1,0,0.4),
        background_normal = '')
        self.button_ajouter.bind(on_press = self.modificateur)
  
        box_val.add_widget(self.button_ajouter)
       
        self.button_valider = Button(
        text= 'Enregistrer',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,1,0.4),
        background_normal = '')
        box_val.add_widget(self.button_valider)
        
        self.button_valider.bind(on_press = self.enregistrement)
 
        self.add_widget (box_val)
        
        #
        
        box_anul = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.},
        size_hint = (1,0.08))
        
        self.button_annule = Button(
        text= 'Suprimer',
        font_name = 'Roboto-Bold.ttf',
        background_color = (1,0.,0,0.4),
        background_normal = '')
        self.button_annule.bind(on_press = self.suprimer)
        
        box_anul.add_widget(self.button_annule)
        
        self.boutonretour= Button (
        text = 'Sortir >',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,0,0.15),
        background_normal ='')
        
        self.boutonretour.bind (on_press = self.manageretour)
        
        box_anul.add_widget(self.boutonretour)

        self.add_widget (box_anul)
        
        with self.canvas.before:
          self.rect = Rectangle(
        source = f"{os.path.abspath('assets/images/file_0000000074f07246a51a0f9ce144e4e3.png')}")
          
        def autoposing(*args):
           self.rect.pos = self.pos
           self.rect.size = self.size
          
        self.bind(
        pos = autoposing,
        size = autoposing)
        
  def  manageretour (self,instance):
        self.manager.current = 'Saisi_Facture'
        
  def next_focus (self,next_input):
      next_input.focus = True     
          
  def suprimer(self,instance):
       box_choix = BoxLayout(
          padding= 10,
          spacing = 10) 
          
       self.avertisement= Popup(
          title = 'Êtes-vous sûr de vouloir suprimer ?',
          content = box_choix ,
          size_hint = (0.8,0.2),
          pos_hint ={'x':0.1,'y':0.4},
          background_color = (0,0,0,0.3))
          
       self.avertisement.open()
       
       self.button_non = Button(
       text = 'Non',
       font_name = 'Roboto-Bold.ttf',
       background_color = (0,0,0,0.3))
       
       box_choix.add_widget(self.button_non)
       
       self.avertisement.open()
       
       self.button_non.bind(on_press = lambda instance: self.avertisement.dismiss())
       
       self.button_oui = Button(
       text = 'Oui',
       font_name = 'Roboto-Bold.ttf',
       background_color = (0,0,0,0.3))
       self.button_oui.bind(on_press = self.confirmation)
       box_choix.add_widget(self.button_oui)
       
       
  def confirmation (self,instance):
        resultat = print_by_code(self.rech_code.text)
        for resultat in resultat:
            result = int (resultat[14])
        if result == 0:
            suppression(self.text_ref.text)
            self.suces= Popup(
            title = 'Suces',
            content = Label (text = f'Suprimer avec suces') ,
            size_hint = (0.8,0.2),
            pos_hint ={'x':0.1,'y':0.4},
            background_color = (0,0,0,0.3))
            self.suces.open()
            self.avertisement.dismiss()
        else :
             self.refus= Popup(
             title = 'Produit en mouvement',
             content = Label (text = 'Ce produit ne peut être suprimé') ,
             size_hint = (0.8,0.2),
             pos_hint ={'x':0.1,'y':0.4},
             background_color = (0,0,0,0.3))
             self.refus.open()   
             self.avertisement.dismiss()
            
           
  def enregistrement(self,instance):
     
      stock = self.type_stock.text
      quantite = 0
      
      if stock == '':
          self.prevenu = Popup(
          title = 'Champ obligatoire',
          content = Label (text = "Entrez s'il vous plait le type de dépôt"),
          size_hint = (0.8,0.2),
          pos_hint ={'x':0.1,'y':0.4},
          background_color = (0,0,0,0.3))
          
          self.prevenu.open()
          
      else:
          depot_id = save_depot(stock)
          produit_id = save_products(get_times(),self.text_ref.text,self.text_design.text,self.text_ean.text,self.text_categ.text,self.text_sfamille.text,self.text_poids.text,self.colis.text,self.prix_achat.text,self.prix_achat_detail.text,self.colis_vente.text,self.prix_detail_v.text)
          
          update_stock(produit_id,depot_id,quantite)
          
          self.text_ref.text = ''
          self.text_design.text = ''
          self.text_ean.text = ''
          self.text_categ.text = ''
          self.text_sfamille.text = ''
          self.text_poids.text = ''
          self.colis.text = ''
          self.prix_achat.text = ''
          self.prix_achat_detail.text = ''
          self.colis_vente.text = ''
          self.prix_detail_v.text = ''
          
  def  modificateur (self,instance):
      modification(
          self.text_ref.text,
          self.text_design.text,
          self.text_ean.text,
          self.text_categ.text,
          self.text_sfamille.text,
          self.text_poids.text,
          self.colis.text,
          self.prix_achat.text,
          self.prix_achat_detail.text,
          self.colis_vente.text,
          self.prix_detail_v.text
         )
      self.sucess = Popup(
          title = 'Sucess',
          content = Label (text = "Modifier avec sucess"),
          size_hint = (0.8,0.2),
          pos_hint ={'x':0.1,'y':0.4},
          background_color = (0,0,0,0.3))
          
      self.sucess.open()
      
  def sheach_code(self,instance,value) :
      result = shearch_by_code(value) 
            
      self.spin_code.values = result
      
      self.spin_code.bind(text = self.send_code)
      
  def shearch_designation (self,instance,value):
       result = shearch_by_design(value)    
          
       self.spin_design.values = list(result)
       
       self.spin_design.bind(text = self.send_designation)
       
  def send_designation(self,instance,value):
      self.rech_design.text = value
      
  def send_code(self,instance,value):
      
      self.rech_code.text = value                
            
  def shearch_depot(self,instance,value):
       resultat = shearching_depot()  
       self.depot_type.values = list(resultat)  
       self.depot_type.bind(text = self.print_depot)
  
  def  print_depot   (self,instance,value):
        self.type_stock.text = value      
        
  def proposition_prix_colis(self,instance):
      
      resultat_1 = trouver_prix_d(self.colis.text,self.prix_achat.text)
      
      self.prix_achat_detail.text = str(resultat_1)
      
      resultat_2 = proposer_prix_colis(self.prix_achat.text,self.pourcentage_c.text)
      
      resultat_3 = proposer_prix_detail(self.prix_achat_detail.text,self.pourcentage_d.text)
      
      self.colis_vente.text = str(resultat_2)
      
      self.prix_detail_v.text = str(resultat_3)
      
      
  def print_values_design (self,instance):
        try:
          resultat = print_by_code(self.rech_design.text)
          resultat = resultat[0]
          self.text_ref.text =resultat[1]
          self.text_design.text = resultat [2]
          self.text_ean.text = resultat [3]
          self.text_categ.text = resultat [4]
          self.text_sfamille.text = str(resultat[5])
          self.text_poids.text = str(resultat [6])
          self.colis.text = str(resultat [7])
          self.prix_achat.text = str(resultat [8])
          self.prix_achat_detail.text = str(resultat [9])
          self.colis_vente.text = str(resultat [10])
          self.prix_detail_v.text = str(resultat [11])
          self.type_stock.text = str(resultat [13])
        except IndexError:
            pass
        return
            
    
  def print_values_code (self,instance):
       try:
          resultat = print_by_code(self.rech_code.text)
          resultat = resultat[0]
          self.text_ref.text = str(resultat[1])
          self.text_design.text = str(resultat [2])
          self.text_ean.text = str(resultat [3])
          self.text_categ.text = str(resultat [4])
          self.text_sfamille.text = str(resultat[5])
          self.text_poids.text = str(resultat [6])
          self.colis.text = str(resultat [7])
          self.prix_achat.text = str(resultat [8])
          self.prix_achat_detail.text = str(resultat [9])
          self.colis_vente.text = str(resultat [10])
          self.prix_detail_v.text = str(resultat [11])
          self.type_stock.text = str(resultat [13])
       except IndexError:
           pass   
       return
      
          