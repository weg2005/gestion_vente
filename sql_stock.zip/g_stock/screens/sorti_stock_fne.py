from kivy.uix.screenmanager import Screen
from kivy.utils import platform
from jnius import autoclass,cast
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.graphics import Color,Rectangle,RoundedRectangle
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
import os
from database.mouvement_bl import print_next_fne,get_next_fne,enregistrement,mouvementprint

from database.products import shearchby_code_design,shearching_depot,print_by_code,get_id_depot,reduct_stock,convert2pdf

from database.connexion import print_name

from logistique.calcule import add_in_stockt_fne,afficher_stock_fne,calcule_montant,supression_prdt_fne

from datetime import datetime

def get_times ():
    return datetime.now().strftime('%d-%m-%Y %H:%M:%S') 

class SortiFNE(Screen):
    def __init__(self, **kwargs):
        super(SortiFNE, self).__init__(**kwargs)
        
        box_title = BoxLayout(
        orientation = 'vertical',
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.8},
        size_hint = (1,0.2))
        
        self.title = Label (text = "SORTI STOCK PAR FNE\nFacture normalisé électronique",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
        
        box_title.add_widget (self.title)
        
        box_compteur = BoxLayout(
        padding = 10,
        spacing = 10)
      
        self.facture = Label (text = "N°FNE:",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
        
        box_compteur.add_widget (self.facture)
        
        self.numero_fact = Label (text = f"{print_next_fne()}",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
        
        box_compteur.add_widget(self.numero_fact)
        box_title.add_widget(box_compteur)
        
        self.add_widget (box_title) 
        
        box_rech_client = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.75},
        size_hint =(1,0.07))
        
        self.bare_rech = TextInput (
        hint_text = "rechercher par code / nom du client",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        font_size = 20,
        foreground_color = (1,1,1,1))
        
        box_rech_client.add_widget (self.bare_rech)
        
        self.add_widget (box_rech_client)
        
        #
        box_client_spin = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.73},
        size_hint =(1,0.02))
        
        self.client_spin = Spinner (
        background_color = (0,0,0,0.15),
        text = "v")
        box_client_spin.add_widget (self.client_spin)
        self.add_widget (box_client_spin)
        # 
        
        box_afficheur = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.66},
        size_hint =(1,0.07))
        
        self.numero = TextInput (
        hint_text = "Numéro téléphone",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        box_afficheur.add_widget (self.numero)
        
        self.cptcontr = TextInput (
        hint_text = "Cpte contribuable",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        box_afficheur.add_widget (self.cptcontr)
        
        
        self.add_widget (box_afficheur)
        
        #
        
        box_afficheur_2 = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.6},
        size_hint =(1,0.07))
        
        self.gmail = TextInput (
        hint_text = "Gmail@.com",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        box_afficheur_2.add_widget (self.gmail)
        
        self.localite = TextInput (
        hint_text = "Localité",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        box_afficheur_2.add_widget (self.localite)
        
        self.add_widget (box_afficheur_2)
        
        #
        
        box_rech_prod = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.54},
        size_hint =(1,0.07))
        
        self.bare_prod = TextInput (
        hint_text = "Recherche par code, EAN,designation",
        background_color = (0,0,0,0.15),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        self.bare_prod.bind(text= self.rechercherpar_code_design)
        
        self.bare_prod.bind(on_text_validate = self.afficher_resultat)
        
        box_rech_prod.add_widget (self.bare_prod)
        
        self.spin_stock = Spinner (
        background_color = (0,0,0,0.15),
        text = "Type stock",
        font_name = 'Roboto-Bold.ttf',
        values = list(shearching_depot()),
        size_hint = (0.4,1))
        
        box_rech_prod.add_widget (self.spin_stock)
        
        self.text_quantite = TextInput (
        hint_text = "Qté",
        background_color = (0,0,0,0.15),
        size_hint = (0.15,1),
        font_name = "Roboto-Bold.ttf",
        multiline = False,
        foreground_color = (1,1,1,1))
        
        box_rech_prod.add_widget (self.text_quantite)
        
        self.text_quantite.bind(on_text_validate = self.ajout_temporaire)
        
        self.add_widget(box_rech_prod)
        
        #
        
        box_prod_spin = BoxLayout (
        padding= 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.52},
        size_hint =(0.7,0.03))
        
        self.prod_spin = Spinner (
        background_color = (0,0,0,0.15),
        text = "v")
        
        box_prod_spin.add_widget (self.prod_spin)
        
        self.add_widget (box_prod_spin)
        
        #
        
        box_info = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.45},
        size_hint = (1,0.06))
      
        self.stock = Label(
        text = "D_",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
      
        box_info.add_widget (self.stock)
      
        self.quantite = TextInput(
        hint_text = "_",
        background_color = (0,0,0,0.3),
        font_size = 20,
        foreground_color = (1,1,1,1),
        font_name = "Roboto-Bold.ttf",
        keyboard = False,
        readonly = True,
        allow_copy = False)
      
        box_info.add_widget (self.quantite)
      
        self.stock_2 = Label(
        text = "D_",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
      
        box_info.add_widget (self.stock_2)
      
        self.quantite_2 = TextInput(
        hint_text = "_",
        background_color = (0,0,0,0.3),
        foreground_color = (1,1,1,1),
        font_size = 35,
        font_name = "Roboto-Bold.ttf",
        keyboard = False,
        readonly = True,
        allow_copy = False)
      
        box_info.add_widget (self.quantite_2)
      
        self.stock_3 = Label(
        text = "D_",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf")
      
        box_info.add_widget (self.stock_3)
      
        self.quantite_3 = TextInput(
        hint_text = "_",
        background_color = (0,0,0,0.3),
        font_size = 20,
        font_name = "Roboto-Bold.ttf",
        foreground_color = (1,1,1,1),
        keyboard = False,
        readonly = True,
        allow_copy = False)
      
        box_info.add_widget (self.quantite_3)
      
        self.colis = Label(
        text = "Colis: _ _",
        color = (1,1,1,1),
        font_size = 20,
        font_name = "Roboto-Bold.ttf",
        size_hint = (0.7,1),
      )
        box_info.add_widget (self.colis)
      
        self.add_widget(box_info)
      
        #
        
        
        # Boxlayout button annuler
        box_annuler = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.03,'y':0.01},
        size_hint = (0.3,0.07),
        )
        
        self.annuler = Button(
        text = 'Annuler',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,0,0))
        
        self.annuler.bind(on_press = self.manageretour)
        
        box_annuler.add_widget(self.annuler)
        
        self.add_widget(box_annuler)
        
        with box_annuler.canvas.before:
            Color (0.7,0.3,0,1)
            self.rounded = RoundedRectangle(
            )
            
        def colored (*args):
            self.rounded.pos = box_annuler.pos
            self.rounded.size = box_annuler.size
            
        box_annuler.bind(
        pos = colored,
        size = colored)
        
         # Boxlayout button supprimer
         
        box_suprimer = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.36,'y':0.01},
        size_hint = (0.3,0.07),
        )
        
        self.suprimer = Button(
        text = 'Suprimer',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,0,0))
        self.suprimer.bind(on_press = self.suppression)
        box_suprimer.add_widget(self.suprimer)
        
        self.add_widget(box_suprimer)
        
        self.scroll_apercu = ScrollView(
        pos_hint = {'x':0.,'y':0.2},
        size_hint = (1,0.25),
        )
        self.boxliste = BoxLayout(
         padding=10,
         spacing=10,
         size_hint_y=None,
         orientation = 'vertical'
        )    
        self.boxliste.bind(minimum_height=self.boxliste.setter('height'))
        self.scroll_apercu.add_widget(self.boxliste)
        
        self.add_widget(self.scroll_apercu)
        
        with box_suprimer.canvas.before:
            Color (1,0,0,1)
            self.rounded_2 = RoundedRectangle(
            )
            
        def colored_2 (*args):
            self.rounded_2.pos = box_suprimer.pos
            self.rounded_2.size = box_suprimer.size
            
        box_suprimer.bind(
        pos = colored_2,
        size = colored_2)
        
        # Boxlayout button valider
         
        box_valider = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.69,'y':0.01},
        size_hint = (0.3,0.07),
        )
        
        self.valider = Button(
        text = 'Valider',
        font_name = 'Roboto-Bold.ttf',
        background_color = (0,0,0,0))
        self.valider.bind(on_press = self.validation_fact)
        box_valider.add_widget(self.valider)
        
        self.add_widget(box_valider)
        
        with box_valider.canvas.before:
            Color (0,1,0,1)
            self.rounded_3 = RoundedRectangle(
            )
            
        def colored_3 (*args):
            self.rounded_3.pos = box_valider.pos
            self.rounded_3.size = box_valider.size
            
        box_valider.bind(
        pos = colored_3,
        size = colored_3)
        
        # Boxlayout comptabilite
      
        box_compt = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.14},
        size_hint = (1,0.06))  
      
        self.HT = TextInput (
        hint_text = 'H.T',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False,
        keyboard = False,
        allow_copy = False,
        readonly = True)
        
        box_compt.add_widget (self.HT)  
      
        self.TVA = TextInput (
        hint_text = 'T.V.A',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False,
        keyboard = False,
        readonly= True,
        allow_copy = False)
      
        box_compt.add_widget(self.TVA) 
        
        self.timbre = TextInput (
        text = '0',
        hint_text = 'Timbre',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False,
        size_hint = (0.5,1)
      )         
      
        box_compt.add_widget (self.timbre)
        
        self.add_widget (box_compt)
        
      # boxlayout contabilite 2
      
        box_compt_2 = BoxLayout(
        padding = 10,
        spacing = 10,
        pos_hint = {'x':0.,'y':0.08},
        size_hint = (1,0.06))
        
        self.remise = TextInput (
        hint_text = 'Remise',
        text = '0',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False)
      
      
        box_compt_2.add_widget(self.remise) 
      
        self.net_payer = TextInput (
        hint_text = 'Net à payer',
        background_normal='',
        background_active='',
        background_color=(0, 0, 0, 0.15),  
        foreground_color=(1, 1, 1, 1),
        font_name = "Roboto-Bold.ttf",
        font_size = 30,
        multiline = False,
        keyboard = False,
        allow_copy = False,
        readonly = True)
      
        box_compt_2.add_widget(self.net_payer)  
        self.add_widget (box_compt_2)
        
     
        with self.canvas.before:
          self.rect = Rectangle(
          source = fr"{os.path.abspath('assets/images/img_caisse.png')}")
          
        def autoposing(*args):
           self.rect.pos = self.pos
           self.rect.size = self.size
          
        self.bind(
        pos = autoposing,
        size = autoposing)

    def  manageretour (self,instance):
        self.manager.current = 'Saisi_Facture'
        
        
    def  rechercherpar_code_design(self,instance,text):
       result = shearchby_code_design(text)
       self.prod_spin.values = list(result)
       self.prod_spin.bind(text = self.send_shearch_product)

    def afficher_resultat(self,intance):
        self.stock.text = ''
        self.quantite.text = ''
        self.stock_2.text = ''
        self.quantite_2.text = ''
        self.stock_3.text = ''
        self.quantite_3.text = ''
        try:
            result = print_by_code(self.bare_prod.text)
        
            produit = result[0]
            type_depot = produit[13]
            id_depot = get_id_depot(type_depot)
            self.bare_prod.text = str(produit[2])
            self.colis.text = str(produit [7])
            
            depot = []
            quantite = []
            for i,row in enumerate (result) :
                depot.append (row[12])
                quantite.append(row[14])
                
            self.stock.text = f'D{(depot[0])}'
            self.quantite.text = str(quantite[0])
                
            self.stock_2.text = f'D{(depot[1])}'
            self.quantite_2.text = str(quantite[1])
            self.stock_3.text = f'D{(depot[2])}'
            self.quantite_3.text = str(quantite[2])
         
        except IndexError:
            pass
        
    def send_shearch_product(self,instance,text) :
        self.bare_prod.text = text
        
    def suppression(self,instance):
        supression_prdt_fne()
        self.boxliste.clear_widgets()
        
    def validation_fact (self,instance):
       Poids = 0
       tva = 0
       ht = 0
       net_payer = 0
       for stock in afficher_stock_fne(): 
       
           id_article = stock['id_article']
           id_depot = stock['id_depot']
           quantite = stock['quantite']
           code = stock['code']
           design = stock['designation']
           prix_achat = stock['prix_vente']
           remise = stock['remise']
           montant = stock['montant']
           tva += stock['TVA']
           ht += stock['HT']
           av_prix = stock['sous prix']
           Remise = stock['Remise']
           timbre = stock['timbre']
           net_payer += stock['net a payer']
           depot = stock['depot']
           colis = stock['colis']
           poids = stock['poids'] 
           Poids += poids * quantite
           Poids = round(Poids / 1000)
           
           reduct_stock (id_article,id_depot,quantite)
           
           enregistrement(print_next_fne(),get_times(),print_name(),code,design,quantite,colis,prix_achat,remise,montant,tva,ht,av_prix,Remise,timbre,net_payer,depot,poids)    
              
       convert2pdf (nom_entreprise = 'Supermarche Petit Paris',telephone = '25672828238',email = 'email@.gmail.com', CDI = 'impôt Abengourou',RC = "",contrib = '900-5903-E SGBCI : 361 300 373 97',RI = 'REEL NORMAL',BL = f'{print_next_fne()}',frs =self.bare_rech.text,BP = '225 Abengourou',enregistreur = f'{print_name()}',date = f'{get_times()}',HT = f'{ht}',TVA= f'{tva}',remise = f'{Remise}',net_payer = f'{net_payer}',poids = f'{Poids}',titre = 'FACTURE',text = mouvementprint(print_next_fne()))      

       self.compteur =print_next_fne()
                     
       box_choix = BoxLayout (
                    padding = 30,
                    spacing = 10
                                )  
       b_oui = Button(text = "Oui",
                                           background_color = (0,0,0,0.3)) 
       b_oui.bind(on_press = self.oui)
       box_choix.add_widget(b_oui)
                            
       b_non = Button(text = "Non",
                                           background_color = (0,0,0,0.3)) 
       b_non.bind(on_press = lambda instance: self.suces.dismiss())
       box_choix.add_widget(b_non)
                       
       self.suces = Popup(
                        title = 'Opperation reussie voulez vous imprimer ?',
                        background_color = (0,0,0,0.3),
                        content = box_choix,
                        size_hint = (0.8,0.2),
                        pos_hint = {'x':0.1,'y':0.4})
       self.suces.open()
              
       
       supression_prdt_fne()
       self.boxliste.clear_widgets()
       get_next_fne()
       self.numero_fact.text = f'{print_next_fne()}'
    
    def ajout_temporaire(self,instance):
        
        result = print_by_code( self.bare_prod.text)
        resultat = result[0]
        avant_prix = 0
        net_payer  = 0
        hort_taxe = 0
        taxe_v_a = 0
        
        try:
             type_depot = self.spin_stock.text
             
             id_article = resultat[0]
             id_depot = get_id_depot(type_depot)
             code = resultat[1]
             poids = int(resultat[6])
        
             design =  self.bare_prod.text
             quantite = int (self.text_quantite.text)
             if id_depot == 1:
               prix_vente = int(resultat[11])
             else:
                prix_vente = int(resultat[10])  
             timbre = int(self.timbre.text)
             remise_2 = int(self.remise.text)
             remise = 0
             colis = int(resultat[7])
         
             montant = calcule_montant(quantite,prix_vente,remise) 
             add_in_stockt_fne(design,quantite,colis,prix_vente,type_depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant)
             self.bare_prod.text = ''
             self.quantite.text = ''
             
             self.boxliste.clear_widgets()
             for resultat in afficher_stock_fne():
                  self.liste = BoxLayout(
                  padding=10,
                  spacing=10,
                  size_hint_y=None)
                  self.liste.bind(minimum_height=self.liste.setter('height'))
                  self.boxliste.add_widget(self.liste)
        
                  self.liste.add_widget(Label(text = f"{resultat['code']}",font_name='Roboto-Bold.ttf',
        color = (1,1,1,1),
        size_hint_y = None
        ))
                  self.liste.add_widget(Label(text = f"{resultat['designation']}",font_name='Roboto-Bold.ttf',
        color = (1,1,1,1),
        size_hint_y = None))
        
                  self.liste.add_widget(
                  Label(
                  text = f"{resultat['quantite']}",
                  font_name='Roboto-Bold.ttf',
                  color = (1,1,1,1),
                  size_hint_y = None)
                  )
        
                  self.liste.add_widget(
                  Label(
                  text =f"{resultat['prix_vente']}",
                  font_name='Roboto-Bold.ttf',
                  color = (1,1,1,1),
                  size_hint_y = None)
        )
        
                  self.liste.add_widget(Label(text =f"{resultat['montant']}",font_name='Roboto-Bold.ttf',
        color = (1,1,1,1),
        size_hint_y = None)) 
                  
                  net_payer += resultat ['net a payer']
                  hort_taxe += round(resultat ['HT'])
                  taxe_v_a += round(resultat ['TVA'])
                  self.net_payer.text = str(net_payer)
                  self.HT.text = str(hort_taxe)
                  self.TVA.text = str(taxe_v_a)    
        except ValueError:
          pass

    def oui(self,instance):
        pdf_path = f"{os.path.abspath(self.compteur)}.pdf"
        if platform == 'android':
            try:
            
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                Intent = autoclass('android.content.Intent')
                Uri = autoclass('android.net.Uri')
                File = autoclass('java.io.File')
                FileProvider = autoclass('androidx.core.content.FileProvider')

                currentActivity = PythonActivity.mCurrentActivity
                context = currentActivity.getApplicationContext()
            
                pdf_file = File(pdf_path)
            
                uri = FileProvider.getUriForFile(
                context,
                context.getPackageName() + ".fileprovider",
                pdf_file
            )

                intent = Intent(Intent.ACTION_VIEW)
                intent.setDataAndType(uri, "application/pdf")
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                currentActivity.startActivity(Intent.createChooser(intent, "Ouvrir PDF"))
            
            except Exception as e:
                print(f"Erreur ouverture PDF: {e}")
        else:
            os.startfile(pdf_path)
        
        self.suces.dismiss()
   
                                    
    