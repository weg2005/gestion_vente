# screens/inventaire tournant

from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.graphics import Color,Rectangle,RoundedRectangle
from kivy.uix.scrollview import ScrollView
from kivy.uix.popup import Popup
from database.mouvement_bl import print_next_sortibl,get_next_sortibl,enregistrement,mouvementprint
from database.products import shearchby_code_design,shearching_depot,print_by_code,get_id_depot,reduct_stock,convert2pdf
from database.connexion import print_name
from logistique.calcule import add_in_stockt_sbl,afficher_stock_sbl,calcule_montant,supression_prdt_sbl
from datetime import datetime
import os

def get_times ():
    return datetime.now().strftime('%d-%m-%Y %H:%M:%S')

class InventaireTournant(Screen):
    def __init__(self, **kwargs):
        super(InventaireTournant, self).__init__(**kwargs)
        pass