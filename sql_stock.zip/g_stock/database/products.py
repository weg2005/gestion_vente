# database/products
from fpdf import FPDF
#from database.connexion import print_name
import sqlite3
import os
dirname = os.path.dirname(os.path.abspath(__file__))
path_name = os.path.join(dirname,"products.db")

connect = sqlite3.connect (path_name)
cursor = connect.cursor()

cursor.execute ("""CREATE TABLE IF NOT EXISTS Articles (id INTEGER PRIMARY KEY AUTOINCREMENT,DATE_ENREGISTREMENT TEXT,CODE TEXT UNIQUE,DESIGNATION TEXT,CODE_BARRE TEXT,CATEGORIE TEXT,SOUS_CATEGERORIE TEXT,POIDS NUMERIC,COLISAGE NUMERIC, PRIX_ACHAT NUMERIC, PRIX_DETAIL_ACHAT NUMERIC,PRIX_VENTE NUMERIC,PRIX_DETAIL_VENTE NUMERIC) """)

cursor.execute(""" CREATE TABLE IF NOT EXISTS type_stock (id INTEGER PRIMARY KEY AUTOINCREMENT,nom TEXT UNIQUE) """)

cursor.execute ("""CREATE TABLE IF NOT EXISTS quantite_stock (id INTEGER PRIMARY KEY AUTOINCREMENT,
id_article INTEGER,
id_stock INTEGER, 
quantite INTEGER,
UNIQUE (id_article,id_stock),
FOREIGN KEY (id_article) REFERENCES Articles (id),
FOREIGN KEY (id_stock) REFERENCES  type_stock(id))""")

#cursor.execute ("""DROP TABLE IF EXISTS type_stock """)

#cursor.execute ("""DROP TABLE IF EXISTS Articles """)

#cursor.execute ("""DROP TABLE IF EXISTS quantite_stock """)

connect.commit()

def save_products (DATE_ENREGISTREMENT,CODE,DESIGNATION,CODE_BARRE,CATEGORIE,SOUS_CATEGERORIE,POIDS,COLISAGE, PRIX_ACHAT, PRIX_DETAIL_ACHAT,PRIX_VENTE,PRIX_DETAIL_VENTE):
    cursor.execute ("""INSERT INTO Articles (DATE_ENREGISTREMENT,CODE,DESIGNATION,CODE_BARRE,CATEGORIE,SOUS_CATEGERORIE,POIDS,COLISAGE, PRIX_ACHAT, PRIX_DETAIL_ACHAT,PRIX_VENTE,PRIX_DETAIL_VENTE) VALUES  (?,?,?,?,?,?,?,?,?,?,?,?) """, (DATE_ENREGISTREMENT,CODE,DESIGNATION,CODE_BARRE,CATEGORIE,SOUS_CATEGERORIE,POIDS,COLISAGE, PRIX_ACHAT, PRIX_DETAIL_ACHAT,PRIX_VENTE,PRIX_DETAIL_VENTE))
    connect.commit()
    
    return cursor.lastrowid
    
def save_depot(nom):
    cursor.execute("SELECT id FROM type_stock WHERE nom = ?", (nom,))
    result = cursor.fetchone()

    if result:
        return result[0]

    cursor.execute("INSERT INTO type_stock (nom) VALUES (?)", (nom,))
    connect.commit()
    
    return cursor.lastrowid

def shearching_depot():
    cursor.execute(""" SELECT nom FROM type_stock """)
    resultat = cursor.fetchall()
    return [resultat[0] for resultat in resultat] if resultat else ''
   
  
def save_quantity(id_product,id_stock,quantite):
    cursor.execute (""" INSERT INTO quantite_stock (id_article,id_stock,quantite) VALUES(?,?,?)""" ,(id_product, id_stock, quantite,))
    connect.commit()
    
def  shearch_by_code(code):
    cursor.execute (""" SELECT CODE FROM Articles WHERE CODE LIKE ? """,(f'%{code}%',))
    
    result = cursor.fetchall()
    return [result[0] for result in result] if result else ''
    
    
def  shearch_by_design(design):
    cursor.execute (""" SELECT DESIGNATION FROM Articles WHERE DESIGNATION LIKE ? """,(f'%{design}%',)) 
    result = cursor.fetchall()
    return [result[0] for result in result] if result else ''
          
def  shearchby_code_design(code):
    cursor.execute (""" SELECT DESIGNATION FROM Articles WHERE  DESIGNATION LIKE ? OR CODE LIKE ? OR CODE_BARRE  LIKE ? """,(f'%{code}%',f'%{code}%',f'%{code}%'))
    
    result = cursor.fetchall()
    return [result[0] for result in result] if result else ''    
    
def print_by_code (code) :
    
    cursor.execute (""" SELECT
    Articles.id,
    Articles.CODE,
    Articles.DESIGNATION,
    Articles.CODE_BARRE,
    Articles.CATEGORIE,
    Articles.SOUS_CATEGERORIE,
    Articles.POIDS,
    Articles.COLISAGE,
    Articles.PRIX_ACHAT,
    Articles.PRIX_DETAIL_ACHAT,
    Articles.PRIX_VENTE,
    Articles.PRIX_DETAIL_VENTE,
    type_stock.id,
    type_stock.nom
    ,quantite_stock.quantite FROM quantite_stock JOIN Articles ON quantite_stock.id_article = Articles.id JOIN type_stock ON quantite_stock.id_stock = type_stock.id WHERE Articles.CODE LIKE ?  OR Articles.DESIGNATION LIKE ?""",(f'%{code}%',f'%{code}%'))
    
    resultat = cursor.fetchall()
    return resultat
    
def modification(code,design,ean,categ,s_cat,poids,colis,prix_ach,prix_d_a,prix_v,prix_v_d):
    cursor.execute(""" UPDATE Articles SET
    DESIGNATION = ?,
    CODE_BARRE = ?,
    CATEGORIE = ?,
    SOUS_CATEGERORIE = ?,
    POIDS = ?,
    COLISAGE = ?,
    PRIX_ACHAT = ?,
    PRIX_DETAIL_ACHAT = ?,
    PRIX_VENTE = ?,
    PRIX_DETAIL_VENTE = ? WHERE CODE = ?""",(design,ean,categ,s_cat,poids,colis,prix_ach,prix_d_a,prix_v,prix_v_d,code))
    connect.commit()
    
def update_stock(id_product , id_stock, quantite):
    cursor.execute("""
    INSERT INTO quantite_stock (id_article,id_stock, quantite)
    VALUES (?, ?, ?)
    ON CONFLICT(id_article, id_stock)
    DO UPDATE SET quantite = quantite + excluded.quantite
    RETURNING id
    """, (id_product, id_stock, quantite))
    row_id = cursor.fetchone()[0] 
    connect.commit()   
    return row_id
    
def reduct_stock(id_product , id_stock, quantite):
    cursor.execute("""
    INSERT INTO quantite_stock (id_article, id_stock, quantite)
    VALUES (?, ?, ?)
    ON CONFLICT(id_article, id_stock)
    DO UPDATE SET quantite = quantite - excluded.quantite
    RETURNING id
    """, (id_product, id_stock, quantite))
    row_id = cursor.fetchone()[0] 
    connect.commit()   
    return row_id    

def get_id_depot(nom):
    cursor.execute("SELECT id FROM type_stock WHERE nom = ?", (nom,))
    result = cursor.fetchone()
    return result[0] if result else None
        
def suppression(code):
    
    # Supprimer d'abord dans quantite_stock
    
    cursor.execute("""
        DELETE FROM quantite_stock
        WHERE id_article = (
            SELECT id FROM Articles WHERE CODE = ?
        )
    """, (code,))

    # Ensuite supprimer dans Articles
    
    cursor.execute("""
        DELETE FROM Articles
        WHERE CODE = ?
    """, (code,))

    connect.commit()
    
def convert2pdf_bl (nom_entreprise,telephone,email, CDI,RC,contrib,RI,BL,frs,BP,enregistreur, date, HT,TVA,remise,net_payer,poids, text):
   
   pdf = FPDF()
   pdf.add_page ()
   
   pdf.set_auto_page_break(auto=True, margin=15)
   
   pdf.set_font('Arial','I',12)
   pdf.cell (0,10,f"Entreprise: {nom_entreprise} ")
   pdf.cell (0,10,f'N°BL: {BL}',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Téléphone: {telephone}')
   pdf.cell (0,10,f'Date & Heure: {date} ',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Email: {email}')
   pdf.cell (0,10,f'Fournisseur: {frs}',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'BP: {BP}')
   pdf.cell (0,10,f'Enregistreur: {enregistreur} ',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Centre des Impôts:{CDI}',ln = 1)
   pdf.cell (0,10,f'Registre du Commerce: {RC}',ln = 1) 
   pdf.cell (0,10,f'Cpte Contribuable: {contrib}',ln = 1)
   pdf.cell (0,10,f"Régime d'imposition: {RI}",ln = 1)
   
   pdf.set_font ('Times','UB',16)
   pdf.cell(0,15,"BON DE RECEPTION",ln = 1,align = 'C')
   
   header = ['Code','Designation','Qté','Colis','PU','Rmse','Montant','Dépôt','Poids']
   border = [15,55,10,20,15,20,20,25,15]
   pdf.set_font ('Arial','B',12)
   
   for h,i in enumerate(header):
       pdf.cell(border[h],7,i,border = 1)
   pdf.ln()
   
   pdf.set_font ('Arial','',10)
   for prod in  text:
       for e,i in enumerate(prod):
           pdf.cell(border[e],5,str(i),border = 1)
       pdf.ln()
       
   pdf.set_font ('Arial','B',10)   
   pdf.cell(55,7,f'H.T: {HT}',border = 1, ln= 1)
   pdf.cell(55,7,f'T.V.A: {TVA}',border = 1, ln= 1)
   pdf.cell(55,7,f'Remise: {remise} ',border = 1, ln= 1)
   pdf.cell(55,7,f'Net à payer : {net_payer} ',border = 1, ln= 1)
   pdf.cell(55,7,f'Total poids: {poids}kg',border = 1, ln= 1)
   
   pdf.output(f'{BL}.pdf')

def convert2pdf (nom_entreprise,telephone,email, CDI,RC,contrib,RI,BL,frs,BP,enregistreur, date, HT,TVA,remise,net_payer,poids,titre, text):
   
   pdf = FPDF()
   pdf.add_page ()
   
   pdf.set_auto_page_break(auto=True, margin=15)
   
   pdf.set_font('Arial','I',12)
   pdf.cell (0,10,f"Entreprise: {nom_entreprise} ")
   pdf.cell (0,10,f'N°: {BL}',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Téléphone: {telephone}')
   pdf.cell (0,10,f'Date & Heure: {date} ',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Email: {email}')
   pdf.cell (0,10,f'Fournisseur: {frs}',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'BP: {BP}')
   pdf.cell (0,10,f'Enregistreur: {enregistreur} ',align = 'R')
   pdf.ln()
   
   pdf.cell (0,10,f'Centre des Impôts:{CDI}',ln = 1)
   pdf.cell (0,10,f'Registre du Commerce: {RC}',ln = 1) 
   pdf.cell (0,10,f'Cpte Contribuable: {contrib}',ln = 1)
   pdf.cell (0,10,f"Régime d'imposition: {RI}",ln = 1)
   
   # TITRE
   pdf.set_font ('Times','UB',16)
   pdf.cell(0,15,f"{titre}",ln = 1,align = 'C')
   
   header = ['Code','Designation','Qté','Colis','PU','Rmse','Montant','Dépôt','Poids']
   border = [15,55,10,20,15,20,20,25,15]
   pdf.set_font ('Arial','B',12)
   
   for h,i in enumerate(header):
       pdf.cell(border[h],7,i,border = 1)
   pdf.ln()
   
   pdf.set_font ('Arial','',10)
   for prod in  text:
       for e,i in enumerate(prod):
           pdf.cell(border[e],5,str(i),border = 1)
       pdf.ln()
       
   pdf.set_font ('Arial','B',10)   
   pdf.cell(55,7,f'H.T: {HT}',border = 1, ln= 1)
   pdf.cell(55,7,f'T.V.A: {TVA}',border = 1, ln= 1)
   pdf.cell(55,7,f'Remise: {remise} ',border = 1, ln= 1)
   pdf.cell(55,7,f'Net à payer : {net_payer} ',border = 1, ln= 1)
   pdf.cell(55,7,f'Total poids: {poids}kg',border = 1, ln= 1)
   
   pdf.output(f'{BL}.pdf')   
 