# database/user_db.py
import sqlite3
import hashlib
from datetime import datetime

DB_NAME = "usersecurity.db"

# Connexion globale
def connection():
    conn = sqlite3.connect(DB_NAME)
    return conn
    
def row_sql():
    row = sqlite3.Row
    return row
    
def suprimersecurty():
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("""DROP TABLE IF EXISTS USERSECURITY_1""")
    conn.commit()
    conn.close()
# Création de la table si elle n'existe pas
def creertable():
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("""
CREATE TABLE IF NOT EXISTS USERSECURITY_1 (
    ID INTEGER PRIMARY KEY AUTOINCREMENT,
    DATE TEXT,
    NOM TEXT,
    MOT_DE_PASSE TEXT,
    ROLE TEXT
)
""")
    conn.commit()
    conn.close()

def get_current_time():
    return datetime.now().strftime("%d-%m-%Y %H:%M:%S")

def hash_password(password):
    """Hashage du mot de passe avec SHA256."""
    return hashlib.sha256(password.encode()).hexdigest()

def add_user(nom, mot_de_passe, role):
    conn = connection()
    cursor = conn.cursor()
    """Ajoute un nouvel utilisateur."""
    cursor.execute("""
    INSERT INTO USERSECURITY_1 (DATE, NOM, MOT_DE_PASSE, ROLE)
    VALUES (?, ?, ?, ?)
    """, (get_current_time(), nom, hash_password(mot_de_passe), role))
    conn.commit()
    conn.close()

def get_user(nom, mot_de_passe):
    conn = connection()
    cursor = conn.cursor()
    """Vérifie si un utilisateur existe avec nom et mot de passe."""
    cursor.execute("""
    SELECT * FROM USERSECURITY_1 WHERE NOM=? AND MOT_DE_PASSE=?
    """, (nom, hash_password(mot_de_passe)))
    resultat =cursor.fetchone()
    conn.commit()
    conn.close()
    return resultat

def count_users():
    """Compte le nombre d'utilisateurs."""
    conn = connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM USERSECURITY_1")
    resultat = cursor.fetchone()[0]
    conn.commit()
    conn.close()
    return resultat