# facture database

import sqlite3
def connection():
    connect_2 = sqlite3.connect ("facture.db")
    return connect_2
    
def surpression_table():
    con = connection()
    cursor = con.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS Facture_data""")
    con.commit()
    con.close()

def creer_table():
    con = connection()
    cursor = con.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS Facture_data(ID NUMERIC PRIMARY KEY ,N°ENREGISTREMENT NUMERIC,CODEENREGISTREMENT TEXT,DATE_ENREGISTREMENT TEXT,N°FOURNISSEUR TEXT,COLIS NUMERIC,NOMFOURNISSEUR TEXT,CODE TEXT,DESIGNATION TEXT,CODE_BARRE TEXT,FAMILLE TEXT,SOUS_FAMILLE TEXT,PRIXACHATCOLIS NUMERIC,PRIXACHATDETAIL NUMERIC,PRIXACHATTOTAL NUMERIC,PRIXVENTECOLIS NUMERIC,PRIXVENTEDETAIL NUMERIC,PRIXVENTETOTAL NUMERIC,HT NUMERIC,TVA NUMERIC,TTC NUMERIC,QUANTITY) """)
    con.commit()
    cursor.execute("""
CREATE UNIQUE INDEX IF NOT EXISTS idx_facture_unique ON Facture_data ("CODEENREGISTREMENT", "CODE");
""")
    con.commit()
    con.close()
def savefacture (N_ENREGISTREMENT,CODEENREGISTREMENT,DATE_ENREGISTREMENT,N_FOURNISSEUR,COLIS,NOMFOURNISSEUR,CODE,DESIGNATION,CODE_BARRE,FAMILLE,SOUS_FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,HT,TVA,TTC,QUANTITE):
    con = connection()
    cursor = con.cursor()
    cursor.execute(""" INSERT INTO Facture_data (N°ENREGISTREMENT,CODEENREGISTREMENT,DATE_ENREGISTREMENT,N°FOURNISSEUR,COLIS,NOMFOURNISSEUR,CODE,DESIGNATION,CODE_BARRE,FAMILLE,SOUS_FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,HT,TVA,TTC,QUANTITY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT (CODEENREGISTREMENT,CODE) DO UPDATE SET QUANTITY = QUANTITY + excluded.QUANTITY""" ,(N_ENREGISTREMENT,CODEENREGISTREMENT,DATE_ENREGISTREMENT,N_FOURNISSEUR,COLIS,NOMFOURNISSEUR,CODE,DESIGNATION,CODE_BARRE,FAMILLE,SOUS_FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,HT,TVA,TTC,int(QUANTITE)))
    con.commit()
    con.close()
# FONCTION MODIFIER

def modify_designation (code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET DESIGNATION = ? WHERE CODE = ?",(valeur,code))
    con.commit()
    con.close()

def modify_colis(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET COLIS = ? WHERE CODE = ?",(valeur,code))
    con.commit()
    con.close()
       
def modify_EAN(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET CODE_BARRE = ? WHERE CODE = ?",(valeur,code))
    con.commit()
    con.close()
    
def modifyprix_AC(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXACHATCOLIS = ? WHERE CODE = ?",(valeur,code))    
    con.commit()
    con.close()
    
def modifyprix_AD(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXACHATDETAIL = ? WHERE CODE = ?",(valeur,code))   
    con.commit()
    con.close()
    
def modifyprix_AT(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXACHATTOTAL = ? WHERE CODE = ?",(valeur,code))   
    con.commit()
    con.close()
    
def modifyprix_VC(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXVENTECOLIS = ? WHERE CODE = ?",(valeur,code))    
    con.commit()
    con.close()
    
def modifyprix_VD(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXVENTEDETAIL = ? WHERE CODE = ?",(valeur,code))   
    con.commit()
    con.close()
    
def modifyprix_VT(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET PRIXVENTETOTAL = ? WHERE CODE = ?",(valeur,code))   
    con.commit()
    con.close()
    
def modifyquantite(code, valeur ) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET QUANTITY = ? WHERE CODE = ?",(valeur,code))   
    con.commit()
    con.close()
def deleded_facture (n_enreg):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" DELETE  FROM Facture_data WHERE CODE = ? """,(n_enreg,))
    con.commit()
    con.close()

def saving_number () :
    con = connection()
    cursor = con.cursor()
    cursor.execute(""" SELECT MAX (N°ENREGISTREMENT) FROM Facture_data""")
    result = cursor.fetchone()[0]
    con.close()
    if result is None:
       return 1
    else:
        return result + 1

def get_sum(n_enregistre):
      con = connection()
      cursor = con.cursor()
      cursor.execute(""" SELECT SUM (PRIXACHATTOTAL) FROM Facture_data WHERE N°ENREGISTREMENT = ? """,(n_enregistre,)) 
      result = cursor.fetchone()[0]  
      
      con.close()
      if result is None:
          return 0
      else:    
          return result               
      
def get_code (code):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT CODE FROM Facture_data WHERE CODE LIKE ? """, (f'%{code}%',) )
    result = cursor.fetchall()
    con.close()
    return [u[0] for u in result] if not None else []
    
def get_designation (designation):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT DESIGNATION FROM Facture_data WHERE DESIGNATION LIKE ? """, (f'%{designation}%',) )
    result = cursor.fetchall()
    con.commit()
    con.close()
    return [u[0] for u in result] if result else []
    
def get_codebarre (codebarre):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT CODE_BARRE FROM Facture_data WHERE CODE_BARRE LIKE ? """, (f'%{codebarre}%',) )
    result = cursor.fetchall()
    con.commit()
    con.close()
    return [u[0] for u in result] if not None else []    
        
def findby_code (code):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT DISTINCT DESIGNATION,CODE_BARRE,CODE,COLIS,SOUS_FAMILLE,FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,QUANTITY,HT,TVA,TTC FROM Facture_data WHERE CODE = ?""",(code,)) 
    result = cursor.fetchall()
    result = result[0]
    con.close()
    return  result 
    
def findby_designation (designation):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT DISTINCT DESIGNATION,CODE_BARRE,CODE,COLIS,SOUS_FAMILLE,FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,QUANTITY,HT,TVA,TTC FROM Facture_data WHERE DESIGNATION = ?""",(designation,)) 
    result = cursor.fetchall ()
    result =result[0]
    con.close()
    return result
    
def findby_codebarre (code):
    con = connection()
    cursor = con.cursor()
    cursor.execute (""" SELECT DISTINCT DESIGNATION,CODE_BARRE,CODE,COLIS,SOUS_FAMILLE,FAMILLE,PRIXACHATCOLIS,PRIXACHATDETAIL,PRIXACHATTOTAL,PRIXVENTECOLIS,PRIXVENTEDETAIL,PRIXVENTETOTAL,QUANTITY,HT,TVA,TTC FROM Facture_data WHERE CODE_BARRE = ?""",(code,)) 
    result = cursor.fetchall()
    result = result[0]
    con.close()
    return  result     
    
def select_apercu (N_ENREG):
    con = connection()
    cursor = con.cursor()
    cursor.execute(""" SELECT CODE_BARRE,CODE,DESIGNATION,COLIS,PRIXACHATCOLIS QUANTITY FROM Facture_data WHERE ? """,(N_ENREG,))  
    result = cursor.fetchall()
    con.close()
    return result[0] if not None else []

def addnew_value (code,qte) :
    con = connection()
    cursor = con.cursor()
    cursor.execute(f"UPDATE Facture_data SET QUANTITY = QUANTITY - ? WHERE CODE = ?",(qte,code))   
    con.commit()
    con.close()