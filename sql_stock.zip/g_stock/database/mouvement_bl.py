# database/mouvement_bl
import sqlite3

def connection():
   return  sqlite3.connect ('mouvement_bl.db')

def creer_table():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteur_bl (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insert_cbl():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("INSERT OR IGNORE INTO compteur_bl (id, valeur) VALUES (1,0)")
    connect.commit()
    connect.close()
    
def drop_comptbl():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteur_bl """)
    connect.commit()
    connect.close()
    
def creer_mouvement():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS mouvement_BL (
         ID INTEGER,
         DATE TEXT,
         UTILISATEUR TEXT,
         code TEXT,
         designation TEXT,
         quantite INTEGER,
         colis INTEGER,
         prix_achat INTEGER,
         remise INTEGER,
         montant INTEGER,
         TVA INTEGER,
         HT INTEGER,
         avant_prix INTEGER,
         remise_2 INTEGER,
         timbre INTEGER,
        net_payer INTEGER,
        depot TEXT,
        poids REAL)""" )
    connect.commit()
    connect.close()
    
def drop_mouvement():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS mouvement_BL """)
    connect.commit()
    connect.close()

def enregistrement(
         ID,
         DATE,
         UTILISATEUR,
         code,
         designation,
         quantite,
         colis,
         prix_achat,
         remise,
         montant,
         TVA,
         HT,
         avant_prix,
         remise_2,
         timbre,
        net_payer,
        depot,
        poids):
            connect = connection()
            cursor = connect.cursor()
            
            cursor.execute(""" INSERT INTO mouvement_BL VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",(ID,DATE,UTILISATEUR, code,designation,quantite,colis,prix_achat,remise,montant,TVA,HT,avant_prix,remise_2,timbre,net_payer,depot,poids))
            connect.commit()
            connect.close()
            
def mouvementprint(id):
        connect = connection()
        cursor = connect.cursor()
        cursor.execute(""" SELECT 
         code,
         designation,
         quantite,
         colis,
         prix_achat,
         remise,
         montant,
         depot,
         poids FROM mouvement_BL WHERE ID = ? """,(id,))
        result = cursor.fetchall()
        connect.commit()
        connect.close()
        return result
        
def get_next_bl():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_bl WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteur_bl SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
    
    return next_val
    
def print_next_bl () :
    connect = connection()
    cursor = connect.cursor()
    
    cursor.execute("SELECT valeur FROM compteur_bl WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.close()
    return f'BR-{current + 1:05d}-ETR'   
     
#====================
# facture entrant
def comptfacture():
    connect = connection()
    cursor = connect.cursor()
    
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteur_facture (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insert_cfct():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteur_facture (id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
    
def drop_comptfact():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteur_facture """)
    connect.commit()
    connect.close()
        
def get_next_fact():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_facture WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteur_facture SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
    
    return next_val
    
def print_next_fact () :
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_facture WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.commit()
    connect.close()
    return f'FACT-{current + 1:05d}-ETR'
    

#====================
# facture sortant
def creertable_facts():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteurfact_str (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insertionfact():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteurfact_str(id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
    
def suprimercompt():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteurfact_str """)
    connect.commit()
    connect.close()
        
def get_next_fne():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteurfact_str WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteurfact_str SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
        
    return next_val
    
def print_next_fne () :
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteurfact_str WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.commit()
    connect.close()
    return f'FNE-{current + 1:05d}-STR'
   
#====================
# bon de livraison sortant
def compteurblsort():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteurbl_str (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insertcompteur ():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteurbl_str(id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
def surprimestrbl():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteurbl_str """)
    connect.commit()
    connect.close()
        
def get_next_sortibl():
    connect = connection()
    cursor = connect.cursor()
    
    cursor.execute("SELECT valeur FROM compteurbl_str WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteurbl_str SET valeur = ? WHERE id = 1", (next_val,))
    
    connect.commit()
    connect.close()
      
    return next_val
    
def print_next_sortibl () :
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteurbl_str WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.close()
    return f'BL-{current + 1:05d}-STR'

#====================
# avoir sur facture
def compt_tableavoir():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteur_avoir (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insertcomptavoir():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteur_avoir(id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
    
def suppression_avoirc():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteur_avoir """)
    connect.commit()
    connect.close()
        
def get_next_avoir():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_avoir WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteur_avoir SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
    
    return next_val
    
def print_next_avoir () :
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_avoir WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.commit()
    connect.close()
    return f'AVR-{current + 1:05d}-FACT'    
    
#====================
# proforma
def creer_comptproforma():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteur_proforma (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insertcompt_prof():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteur_proforma(id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
    
def suppresion_cprof():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteur_proforma """)
    connect.commit()
    connect.close()
        
def get_next_proforma():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_proforma WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteur_proforma SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
    
    return next_val
    
def print_next_proforma () :
    connect = connection()
    cursor = connect.cursor()
    
    cursor.execute("SELECT valeur FROM compteur_proforma WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.commit()
    connect.close()
    return f'PROF-{current + 1:05d}'     
    
#====================
# commande
def creercomp_command():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS compteur_commande (id INTEGER,valeur INTEGER) """)
    connect.commit()
    connect.close()
    
def insertcomp_command():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" INSERT INTO compteur_commande(id, valeur ) VALUES (1,0)""")
    connect.commit()
    connect.close()
    
def supricomptcommand():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute(""" DROP TABLE IF EXISTS compteur_commande""")
    connect.commit()
    connect.close()
        
def get_next_commande():
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_commande WHERE id = 1")
    current = cursor.fetchone()[0]
    
    next_val = current + 1
    
    cursor.execute("UPDATE compteur_commande SET valeur = ? WHERE id = 1", (next_val,))
    connect.commit()
    connect.close()
    return next_val
    
def print_next_commande () :
    connect = connection()
    cursor = connect.cursor()
    cursor.execute("SELECT valeur FROM compteur_commande WHERE id = 1")
    current = cursor.fetchone()[0]
    connect.commit()
    connect.close()
    return f'CMD-{current + 1:05d}'     
    
                 