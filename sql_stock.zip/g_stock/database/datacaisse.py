# base donne caisse

import sqlite3
import os 
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# je decide de creer une base de donne sql pour stocker les informations lier a la caisse
def dirname():
    dirname = os.path.dirname (os.path.abspath(__file__))
    pathname = os.path.join(dirname,"basecaisse.db")
    return pathname
def connection_sql() :
    connect = sqlite3.connect(dirname())
    return connect
def creer_table():
    connect = connection_sql()
    cursor = connect.cursor()

    # creer maintenant ma base de donnee
    # voila ce qu'il faut qu'il enregistre : le nom de la caissiere, la designation du produit vendu, la quantite sortie, la date a a laquelle le produit est sorti la somme total de sa vente durant la journee.
    cursor.execute(""" CREATE TABLE IF NOT EXISTS caissedata(ID INTEGER PRIMARY KEY AUTOINCREMENT,NOMCAISSIER TEXT, NOMPRODUIT TEXT, QTESORTI, DATESORTI TEXT, PRIX NUMERIC,SOMMETOTAL NUMERIC,RECU NUMERIC, DEVOIR NUMERIC,REMISE NUMERIC,COMPTEUR NUMERIC,RECETTE REAL,TYPEPAYE TEXT) """)
    connect.commit()
    connect.close()
def supprimer_table():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("DROP TABLE IF EXISTS caissedata")
    connect.commit()
    connect.close()

def savecaisse_data (nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye):
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute (""" INSERT INTO caissedata (NOMCAISSIER,NOMPRODUIT,QTESORTI,DATESORTI,PRIX,SOMMETOTAL,RECU,DEVOIR,REMISE,COMPTEUR,RECETTE,TYPEPAYE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye))
    connect.commit()
    connect.close()

compte = 0   

def compteur_caisse():
    global compte
    compte += 1   
    return compte  

def generer_img_product(limite = 10,freq = 'h'):
    connect = connection_sql()
    pathdir = os.path.dirname(os.path.abspath(__file__))
    mypath = os.path.join(pathdir,'graph.jpg')
    pathdir_2 = os.path.dirname(os.path.abspath(__file__))
    mypath_2 = os.path.join(pathdir,'graph_2_vent.jpg')
    if os.path.exists(mypath):
       os.remove(mypath)
    if os.path.exists(mypath_2):
        os.remove(mypath_2)
        
    data = pd.read_sql(f"select * from caissedata",connect)
    # on veut pourvoir voir une barre qui nous indique la meilleur vente
    data["DATESORTI"] = pd.to_datetime(data["DATESORTI"])
    data.set_index("DATESORTI",inplace=True)
    resulta = data.groupby("NOMPRODUIT")["QTESORTI"].sum().sort_values(ascending=False)
    resulta= resulta.head(limite)
    resulta.plot(kind="barh")
    plt.xlabel('quantite')
    plt.ylabel('produit')
    plt.title("TOTAL DES VENTE PAR PRODUIT")
    plt.tight_layout()
    plt.savefig(mypath)
    plt.close()
    
    par_heur = data.resample(freq)['SOMMETOTAL'].sum()
    par_heur.plot(kind="bar")
    plt.xlabel('Heure')
    plt.ylabel('Somme')
    plt.title("LA SOMME TOTAL PAR HEURE")
    plt.tight_layout()
    plt.savefig(mypath_2)
    plt.close()
    connect.close()
    
    return mypath,mypath_2


def last_time():
    connect = connection_sql()
    cursor = connect.cursor()
    
    cursor.execute("select DATESORTI from caissedata order by ID desc limit 1")
    resultat = cursor.fetchone()
    connect.commit()
    connect.close()
    return resultat [0] if resultat else ''
   
    


def cummule_jour():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (SOMMETOTAL) FROM caissedata where DATE (DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.commit()
    connect.close()
    return resultat[0] if resultat else ""

def cummele_recette():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (RECETTE) from caissedata where DATE(DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else ""

def nom_actuel():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("select NOMCAISSIER,COMPTEUR from caissedata order by ID desc limit 1")
    resultat = cursor.fetchall()
    connect.commit()
    connect.close()
    return resultat [0] if resultat else ''

print(generer_img_product())