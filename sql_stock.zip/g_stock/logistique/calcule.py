import math

def trouver_prix_d (colis = 0,prix = 0):
    try:
        resultat = int(prix)/int(colis)
        return round(resultat)
    except SyntaxError:
         print('erreur')
    except ZeroDivisionError:
         print('error')      
         
def proposer_prix_colis(prix= 0,pourcentage = 20):
    try:
        pourcentage = float(pourcentage)
        prix = int(prix)
        convertion = pourcentage/100 +1
        proposer = prix * convertion
        return round (proposer)
        
    except ValueError:
        print('error')
        
def calcule_montant (quantite,montant,remise):
    return (quantite * montant) - remise
    
def proposer_prix_detail(prix=0,pourcentage = 20):
    
    try:
        prix = int(prix)
        pourcentage = float(pourcentage)
        convertion = pourcentage/100 +1
        proposer_d = prix * convertion
        
        return round(proposer_d)
        
    except ValueError:
        print('erreur')  
        
    
bl_temporaire = []

def add_in_stockt(designation,quantite,colis,prix_achat,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_achat = int(prix_achat)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    avant_prix = montant
    net_payer = avant_prix - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_achat = int (prix_achat)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_achat": prix_achat,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        bl_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt():
      bl_temporaire.clear()     
      
def afficher_stock():
      return bl_temporaire
      
#===============
# facture

facture_temporaire = []                
      
def add_in_stockt_fact(designation,quantite,colis,prix_achat,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_achat = int(prix_achat)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    avant_prix = montant
    net_payer = avant_prix - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_achat = int (prix_achat)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_achat": prix_achat,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        facture_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_fact():
      facture_temporaire.clear()     
      
def afficher_stock_fact():
      return facture_temporaire  
      
#===============
# fne 

fne_temporaire = []                
      
def add_in_stockt_fne(designation,quantite,colis,prix_vente,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_vente = int(prix_vente)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    net_payer = montant - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_vente = int (prix_vente)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_vente": prix_vente,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        fne_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_fne():
      fne_temporaire.clear()     
      
def afficher_stock_fne():
      return fne_temporaire         
      
#===============
# sortir bl

sortibl_temporaire = []                
      
def add_in_stockt_sbl(designation,quantite,colis,prix_vente,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_vente = int(prix_vente)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    net_payer = montant - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_vente = int (prix_vente)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_vente": prix_vente,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        sortibl_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_sbl():
      sortibl_temporaire.clear()     
      
def afficher_stock_sbl():
      return sortibl_temporaire                          
#===============
# avoir sur facture

avoir_temporaire = []                
      
def add_in_stockt_avoir(designation,quantite,colis,prix_vente,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_vente = int(prix_vente)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    net_payer = montant - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_vente = int (prix_vente)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_vente": prix_vente,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        avoir_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_avoir():
      avoir_temporaire.clear()     
      
def afficher_stock_avoir():
      return avoir_temporaire        
      
#===============
# proforma

proforma_temporaire = []                
      
def add_in_stockt_proforma(designation,quantite,colis,prix_vente,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_vente = int(prix_vente)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    net_payer = montant - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_vente = int (prix_vente)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_vente": prix_vente,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        proforma_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_proforma():
      proforma_temporaire.clear()     
      
def afficher_stock_proforma():
      return proforma_temporaire                    
      
#===============
# commande

commande_temporaire= []                
      
def add_in_stockt_commande(designation,quantite,colis,prix_vente,depot,timbre,remise,code,id_article,id_depot,poids,remise_2,montant):
    
    quantite = int(quantite)
    prix_vente = int(prix_vente)
    remise = int(remise)
    remise_2 = int(remise_2)
    timbre = int(timbre)
    remise = int(remise)
    
    avant_prix = 0
    net_payer = 0
    TVA = 0
    TVA += montant * 0.18 
    HT = montant - TVA 
    net_payer = montant - remise_2 + timbre
    try :
        quantite = int (quantite)
        prix_vente = int (prix_vente)
        stock = {
        'id_article':id_article,
        'id_depot':id_depot,
        'code':code,
        "designation": designation,
        "quantite" : quantite,
        "prix_vente": prix_vente,
        "remise": remise,
        'montant': montant,
        'TVA': TVA,
        'HT': HT,
        'sous prix':avant_prix,
        'Remise': remise_2,
        'timbre': timbre,
        'net a payer':net_payer,
        'depot': depot,
        'poids': poids,
        'colis': colis}
        commande_temporaire.append(stock)
        
    except ValueError :
        print ('erreur')
        
def supression_prdt_commande():
      commande_temporaire.clear()     
      
def afficher_stock_commande():
      return commande_temporaire                                                                                                                          